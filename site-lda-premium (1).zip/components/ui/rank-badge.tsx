'use client'

import { getRankByElo, type RankInfo } from '@/lib/utils/ranks'
import { cn } from '@/lib/utils'

interface RankBadgeProps {
  elo: number
  showElo?: boolean
  size?: 'sm' | 'md' | 'lg'
  className?: string
}

export function RankBadge({ elo, showElo = false, size = 'md', className }: RankBadgeProps) {
  const rank = getRankByElo(elo)

  const sizeClasses = {
    sm: 'text-xs px-1.5 py-0.5',
    md: 'text-sm px-2 py-1',
    lg: 'text-base px-3 py-1.5'
  }

  return (
    <div
      className={cn(
        'inline-flex items-center gap-1 rounded-full font-medium',
        rank.bgColor,
        rank.color,
        `border ${rank.borderColor}`,
        sizeClasses[size],
        className
      )}
    >
      <span>{rank.icon}</span>
      <span>{rank.name}</span>
      {showElo && <span className="opacity-75">({elo})</span>}
    </div>
  )
}

interface RankProgressProps {
  elo: number
  className?: string
}

export function RankProgress({ elo, className }: RankProgressProps) {
  const rank = getRankByElo(elo)
  const nextRankIndex = rank.tier === 'champions' ? -1 : 
    ['copper', 'bronze', 'prata', 'ouro', 'diamante', 'champions'].indexOf(rank.tier) + 1

  const progress = rank.maxElo === Infinity 
    ? 100 
    : ((elo - rank.minElo) / (rank.maxElo - rank.minElo + 1)) * 100

  return (
    <div className={cn('w-full', className)}>
      <div className="flex justify-between text-xs mb-1">
        <span className={rank.color}>{rank.name}</span>
        <span className="text-muted-foreground">{elo} ELO</span>
      </div>
      <div className="h-2 bg-secondary rounded-full overflow-hidden">
        <div
          className={cn('h-full rounded-full transition-all duration-500', rank.bgColor.replace('/20', ''))}
          style={{ width: `${Math.min(100, Math.max(0, progress))}%` }}
        />
      </div>
      {nextRankIndex > 0 && nextRankIndex < 6 && (
        <div className="text-xs text-muted-foreground mt-1 text-right">
          {['Copper', 'Bronze', 'Prata', 'Ouro', 'Diamante', 'Champions'][nextRankIndex]} em{' '}
          {rank.maxElo - elo + 1} ELO
        </div>
      )}
    </div>
  )
}
