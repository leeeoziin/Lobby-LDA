'use client'

import { motion } from 'framer-motion'
import { cn } from '@/lib/utils'
import { ReactNode } from 'react'

interface GlowCardProps {
  children: ReactNode
  className?: string
  glowColor?: 'yellow' | 'gold' | 'silver' | 'bronze'
  hover?: boolean
}

const glowColors = {
  yellow: 'hover:shadow-[0_0_30px_oklch(0.85_0.18_90_/_0.3)]',
  gold: 'hover:shadow-[0_0_30px_oklch(0.78_0.16_85_/_0.3)]',
  silver: 'hover:shadow-[0_0_30px_oklch(0.75_0.02_250_/_0.3)]',
  bronze: 'hover:shadow-[0_0_30px_oklch(0.65_0.12_55_/_0.3)]',
}

export function GlowCard({ 
  children, 
  className, 
  glowColor = 'yellow',
  hover = true 
}: GlowCardProps) {
  return (
    <motion.div
      whileHover={hover ? { scale: 1.02, y: -5 } : undefined}
      transition={{ type: 'spring', stiffness: 300, damping: 20 }}
      className={cn(
        "glass rounded-xl p-6 transition-all duration-300",
        hover && glowColors[glowColor],
        className
      )}
    >
      {children}
    </motion.div>
  )
}
