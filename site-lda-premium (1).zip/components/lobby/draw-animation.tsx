'use client'

import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { MapPin, Users, Swords, Shield, X } from 'lucide-react'
import type { DrawResult } from '@/lib/types/database'
import { cn } from '@/lib/utils'
import { getRankByElo, getTeamAverageElo } from '@/lib/utils/ranks'

interface DrawAnimationProps {
  drawResult: DrawResult
  onComplete: () => void
}

type AnimationPhase = 'intro' | 'map' | 'teams' | 'sides' | 'complete'

export function DrawAnimation({ drawResult, onComplete }: DrawAnimationProps) {
  const [phase, setPhase] = useState<AnimationPhase>('intro')

  useEffect(() => {
    const timers: NodeJS.Timeout[] = []

    timers.push(setTimeout(() => setPhase('map'), 2000))
    timers.push(setTimeout(() => setPhase('teams'), 4500))
    timers.push(setTimeout(() => setPhase('sides'), 7000))
    timers.push(setTimeout(() => setPhase('complete'), 9000))

    return () => timers.forEach(clearTimeout)
  }, [])

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 backdrop-blur-lg"
    >
      {/* Close Button */}
      <button
        onClick={onComplete}
        className="absolute top-4 right-4 p-2 text-muted-foreground hover:text-foreground transition-colors z-50"
      >
        <X className="w-6 h-6" />
      </button>

      {/* Glow Effect */}
      <div className="absolute inset-0 bg-gradient-radial opacity-50 pointer-events-none" />

      <div className="relative w-full max-w-4xl px-4">
        <AnimatePresence mode="wait">
          {/* Intro Phase */}
          {phase === 'intro' && (
            <motion.div
              key="intro"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.2 }}
              className="text-center"
            >
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
                className="w-32 h-32 mx-auto mb-8 rounded-full border-4 border-primary border-t-transparent glow-yellow-lg"
              />
              <motion.h2
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-4xl font-black text-foreground mb-4"
              >
                INICIANDO SORTEIO
              </motion.h2>
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: '100%' }}
                transition={{ duration: 1.5 }}
                className="h-1 bg-primary mx-auto max-w-xs rounded-full glow-yellow"
              />
            </motion.div>
          )}

          {/* Map Phase */}
          {phase === 'map' && (
            <motion.div
              key="map"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="text-center"
            >
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: 'spring', damping: 10 }}
                className="w-24 h-24 mx-auto mb-6 rounded-2xl bg-primary/20 flex items-center justify-center glow-yellow"
              >
                <MapPin className="w-12 h-12 text-primary" />
              </motion.div>
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-xl text-muted-foreground mb-4"
              >
                MAPA SORTEADO
              </motion.p>
              <motion.h2
                initial={{ opacity: 0, scale: 0.5 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.3, type: 'spring' }}
                className="text-5xl font-black text-primary text-glow-lg"
              >
                {drawResult.map?.name || 'Mapa'}
              </motion.h2>
            </motion.div>
          )}

          {/* Teams Phase */}
          {phase === 'teams' && (
            <motion.div
              key="teams"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center mb-8"
              >
                <Users className="w-12 h-12 text-primary mx-auto mb-4" />
                <h2 className="text-3xl font-black text-foreground">TIMES SORTEADOS</h2>
              </motion.div>

              <div className="grid md:grid-cols-2 gap-8">
                {/* Team A */}
                <motion.div
                  initial={{ x: -100, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: 0.2 }}
                  className="glass rounded-xl p-6 border-2 border-red-500/50"
                >
                  <h3 className="text-2xl font-bold text-center mb-2 text-red-500">TIME A</h3>
                  {drawResult.team_a_players && (
                    <p className="text-sm text-center text-muted-foreground mb-4">
                      ELO Medio: {getTeamAverageElo(drawResult.team_a_players.map(p => ({ elo: (p as any).elo || 1000 })))}
                    </p>
                  )}
                  <div className="space-y-3">
                    {drawResult.team_a_players?.map((player, i) => {
                      const rank = getRankByElo((player as any).elo || 1000)
                      return (
                        <motion.div
                          key={i}
                          initial={{ x: -50, opacity: 0 }}
                          animate={{ x: 0, opacity: 1 }}
                          transition={{ delay: 0.3 + i * 0.1 }}
                          className="flex items-center gap-3 p-2 rounded-lg bg-secondary/50"
                        >
                          <div className="w-10 h-10 rounded-full bg-red-500/20 flex items-center justify-center">
                            <span className="font-bold text-red-500">
                              {player.nickname.charAt(0).toUpperCase()}
                            </span>
                          </div>
                          <div className="flex-1">
                            <span className="font-medium">{player.nickname}</span>
                            <div className={`text-xs ${rank.color}`}>{rank.name}</div>
                          </div>
                          <span className="text-xs text-muted-foreground">{player.platform}</span>
                        </motion.div>
                      )
                    })}
                  </div>
                </motion.div>

                {/* Team B */}
                <motion.div
                  initial={{ x: 100, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: 0.2 }}
                  className="glass rounded-xl p-6 border-2 border-blue-500/50"
                >
                  <h3 className="text-2xl font-bold text-center mb-2 text-blue-500">TIME B</h3>
                  {drawResult.team_b_players && (
                    <p className="text-sm text-center text-muted-foreground mb-4">
                      ELO Medio: {getTeamAverageElo(drawResult.team_b_players.map(p => ({ elo: (p as any).elo || 1000 })))}
                    </p>
                  )}
                  <div className="space-y-3">
                    {drawResult.team_b_players?.map((player, i) => {
                      const rank = getRankByElo((player as any).elo || 1000)
                      return (
                        <motion.div
                          key={i}
                          initial={{ x: 50, opacity: 0 }}
                          animate={{ x: 0, opacity: 1 }}
                          transition={{ delay: 0.3 + i * 0.1 }}
                          className="flex items-center gap-3 p-2 rounded-lg bg-secondary/50"
                        >
                          <div className="w-10 h-10 rounded-full bg-blue-500/20 flex items-center justify-center">
                            <span className="font-bold text-blue-500">
                              {player.nickname.charAt(0).toUpperCase()}
                            </span>
                          </div>
                          <div className="flex-1">
                            <span className="font-medium">{player.nickname}</span>
                            <div className={`text-xs ${rank.color}`}>{rank.name}</div>
                          </div>
                          <span className="text-xs text-muted-foreground">{player.platform}</span>
                        </motion.div>
                      )
                    })}
                  </div>
                </motion.div>
              </div>
            </motion.div>
          )}

          {/* Sides Phase */}
          {phase === 'sides' && (
            <motion.div
              key="sides"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="text-center"
            >
              <motion.h2
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-3xl font-black text-foreground mb-8"
              >
                LADOS DEFINIDOS
              </motion.h2>

              <div className="flex justify-center gap-8">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.2, type: 'spring' }}
                  className={cn(
                    "p-8 rounded-2xl",
                    drawResult.team_a_side === 'ATAQUE' 
                      ? "bg-red-500/20 border-2 border-red-500" 
                      : "bg-blue-500/20 border-2 border-blue-500"
                  )}
                >
                  <div className="flex flex-col items-center gap-4">
                    {drawResult.team_a_side === 'ATAQUE' ? (
                      <Swords className="w-16 h-16 text-red-500" />
                    ) : (
                      <Shield className="w-16 h-16 text-blue-500" />
                    )}
                    <div>
                      <p className="text-lg font-bold">TIME A</p>
                      <p className={cn(
                        "text-2xl font-black",
                        drawResult.team_a_side === 'ATAQUE' ? "text-red-500" : "text-blue-500"
                      )}>
                        {drawResult.team_a_side}
                      </p>
                    </div>
                  </div>
                </motion.div>

                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.4, type: 'spring' }}
                  className={cn(
                    "p-8 rounded-2xl",
                    drawResult.team_b_side === 'ATAQUE' 
                      ? "bg-red-500/20 border-2 border-red-500" 
                      : "bg-blue-500/20 border-2 border-blue-500"
                  )}
                >
                  <div className="flex flex-col items-center gap-4">
                    {drawResult.team_b_side === 'ATAQUE' ? (
                      <Swords className="w-16 h-16 text-red-500" />
                    ) : (
                      <Shield className="w-16 h-16 text-blue-500" />
                    )}
                    <div>
                      <p className="text-lg font-bold">TIME B</p>
                      <p className={cn(
                        "text-2xl font-black",
                        drawResult.team_b_side === 'ATAQUE' ? "text-red-500" : "text-blue-500"
                      )}>
                        {drawResult.team_b_side}
                      </p>
                    </div>
                  </div>
                </motion.div>
              </div>
            </motion.div>
          )}

          {/* Complete Phase */}
          {phase === 'complete' && (
            <motion.div
              key="complete"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              className="text-center"
            >
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: 'spring', damping: 10 }}
                className="w-24 h-24 mx-auto mb-6 rounded-full bg-primary flex items-center justify-center glow-yellow-lg"
              >
                <span className="text-4xl font-black text-primary-foreground">LDA</span>
              </motion.div>

              <motion.h2
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-4xl font-black text-foreground mb-4"
              >
                SORTEIO COMPLETO
              </motion.h2>

              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.3 }}
                className="text-xl text-muted-foreground mb-8"
              >
                Boa sorte a todos os jogadores!
              </motion.p>

              <motion.button
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
                onClick={onComplete}
                className="px-8 py-3 bg-primary text-primary-foreground rounded-xl font-bold glow-yellow hover:bg-primary/90 transition-colors"
              >
                FECHAR
              </motion.button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  )
}
