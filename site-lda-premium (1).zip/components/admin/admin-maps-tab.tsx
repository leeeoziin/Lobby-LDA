"use client"

import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { createClient } from '@/lib/supabase/client'
import { Map, Plus, Pencil, Trash2, Check, X, RefreshCw, ToggleLeft, ToggleRight } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { GlowCard } from '@/components/ui/glow-card'

interface MapItem {
  id: string
  name: string
  image_url: string | null
  is_active: boolean
  created_at: string
}

export function AdminMapsTab() {
  const [maps, setMaps] = useState<MapItem[]>([])
  const [loading, setLoading] = useState(true)
  const [newMapName, setNewMapName] = useState('')
  const [editingMap, setEditingMap] = useState<string | null>(null)
  const [editName, setEditName] = useState('')

  const supabase = createClient()

  useEffect(() => {
    fetchMaps()
  }, [])

  async function fetchMaps() {
    setLoading(true)
    const { data } = await supabase
      .from('maps')
      .select('*')
      .order('name')
    
    if (data) setMaps(data)
    setLoading(false)
  }

  async function addMap() {
    if (!newMapName.trim()) return
    
    const { data } = await supabase
      .from('maps')
      .insert({ name: newMapName.trim(), is_active: true })
      .select()
      .single()
    
    if (data) {
      setMaps(prev => [...prev, data].sort((a, b) => a.name.localeCompare(b.name)))
      setNewMapName('')
    }
  }

  async function updateMap(id: string) {
    if (!editName.trim()) return
    
    await supabase
      .from('maps')
      .update({ name: editName.trim() })
      .eq('id', id)
    
    setMaps(prev => prev.map(m => m.id === id ? { ...m, name: editName.trim() } : m))
    setEditingMap(null)
    setEditName('')
  }

  async function toggleMapActive(id: string, isActive: boolean) {
    await supabase
      .from('maps')
      .update({ is_active: !isActive })
      .eq('id', id)
    
    setMaps(prev => prev.map(m => m.id === id ? { ...m, is_active: !isActive } : m))
  }

  async function deleteMap(id: string) {
    if (!confirm('Tem certeza que deseja excluir este mapa?')) return
    
    await supabase.from('maps').delete().eq('id', id)
    setMaps(prev => prev.filter(m => m.id !== id))
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <RefreshCw className="w-8 h-8 text-yellow-500 animate-spin" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Add New Map */}
      <GlowCard>
        <div className="p-6">
          <div className="flex items-center gap-3 mb-4">
            <Plus className="w-5 h-5 text-yellow-500" />
            <h2 className="text-lg font-bold text-white">Adicionar Novo Mapa</h2>
          </div>
          <div className="flex gap-3">
            <Input
              placeholder="Nome do mapa"
              value={newMapName}
              onChange={(e) => setNewMapName(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && addMap()}
              className="bg-black/50 border-white/10 text-white"
            />
            <Button
              onClick={addMap}
              disabled={!newMapName.trim()}
              className="bg-yellow-500 hover:bg-yellow-600 text-black"
            >
              <Plus className="w-4 h-4 mr-2" />
              Adicionar
            </Button>
          </div>
        </div>
      </GlowCard>

      {/* Maps List */}
      <GlowCard>
        <div className="p-6">
          <div className="flex items-center gap-3 mb-6">
            <Map className="w-6 h-6 text-yellow-500" />
            <h2 className="text-xl font-bold text-white">Mapas ({maps.length})</h2>
          </div>

          <div className="grid gap-3">
            <AnimatePresence>
              {maps.map((map) => (
                <motion.div
                  key={map.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className={`flex items-center justify-between p-4 rounded-lg border ${
                    map.is_active 
                      ? 'bg-black/40 border-white/10' 
                      : 'bg-black/20 border-white/5 opacity-60'
                  }`}
                >
                  {editingMap === map.id ? (
                    <div className="flex items-center gap-3 flex-1">
                      <Input
                        value={editName}
                        onChange={(e) => setEditName(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && updateMap(map.id)}
                        className="bg-black/50 border-white/10 text-white"
                        autoFocus
                      />
                      <Button
                        size="sm"
                        onClick={() => updateMap(map.id)}
                        className="bg-green-500 hover:bg-green-600 text-white"
                      >
                        <Check className="w-4 h-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          setEditingMap(null)
                          setEditName('')
                        }}
                        className="border-white/20"
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  ) : (
                    <>
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 rounded-lg bg-yellow-500/20 flex items-center justify-center">
                          <Map className="w-5 h-5 text-yellow-500" />
                        </div>
                        <span className="text-white font-medium">{map.name}</span>
                        {!map.is_active && (
                          <span className="text-xs px-2 py-1 rounded bg-red-500/20 text-red-400">
                            Desativado
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => toggleMapActive(map.id, map.is_active)}
                          className={map.is_active ? 'text-green-500' : 'text-gray-500'}
                        >
                          {map.is_active ? (
                            <ToggleRight className="w-5 h-5" />
                          ) : (
                            <ToggleLeft className="w-5 h-5" />
                          )}
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => {
                            setEditingMap(map.id)
                            setEditName(map.name)
                          }}
                          className="text-blue-400 hover:text-blue-300"
                        >
                          <Pencil className="w-4 h-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => deleteMap(map.id)}
                          className="text-red-400 hover:text-red-300"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </>
                  )}
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>
      </GlowCard>
    </div>
  )
}
