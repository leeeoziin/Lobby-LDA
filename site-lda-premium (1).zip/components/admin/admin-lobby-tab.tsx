'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { 
  Play, 
  Pause, 
  RefreshCw, 
  Trash2, 
  UserMinus,
  UserPlus,
  Shuffle,
  Users,
  Clock,
  MapPin,
  Shield,
  Swords,
  Search
} from 'lucide-react'
import { useLobby, useMaps, usePlayers } from '@/hooks/use-supabase'
import { createClient } from '@/lib/supabase/client'
import { GlowCard } from '@/components/ui/glow-card'
import { RankBadge } from '@/components/ui/rank-badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { cn } from '@/lib/utils'
import { balanceTeams, getTeamAverageElo } from '@/lib/utils/ranks'
import type { LobbyPlayer } from '@/lib/types/database'

const supabase = createClient()

export function AdminLobbyTab() {
  const { lobby, players, loading, refetch } = useLobby()
  const { maps } = useMaps()
  const { players: allPlayers, refetch: refetchPlayers } = usePlayers()
  const [isDrawing, setIsDrawing] = useState(false)
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedPlatform, setSelectedPlatform] = useState<'PC' | 'Xbox' | 'PSN'>('PC')
  const [showAddPlayer, setShowAddPlayer] = useState(false)

  const titulares = players.filter(p => !p.is_reserve)
  const reservas = players.filter(p => p.is_reserve)
  const activeMaps = maps.filter(m => m.is_active)

  // Filter players not in lobby for adding
  const lobbyNicknames = players.map(p => p.nickname.toLowerCase())
  const availablePlayers = allPlayers.filter(p => 
    !lobbyNicknames.includes(p.nickname.toLowerCase()) &&
    p.nickname.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const handleToggleLobby = async () => {
    if (!lobby) return

    await supabase
      .from('lobby')
      .update({ is_open: !lobby.is_open, updated_at: new Date().toISOString() })
      .eq('id', lobby.id)

    refetch()
  }

  const handleResetLobby = async () => {
    if (!lobby || !confirm('Tem certeza que deseja resetar o lobby?')) return

    await supabase
      .from('lobby_players')
      .delete()
      .eq('lobby_id', lobby.id)

    await supabase
      .from('lobby')
      .update({ is_open: true, updated_at: new Date().toISOString() })
      .eq('id', lobby.id)

    refetch()
  }

  const handleRemovePlayer = async (playerId: string) => {
    await supabase
      .from('lobby_players')
      .delete()
      .eq('id', playerId)

    // Promote first reserve to titular
    if (reservas.length > 0) {
      await supabase
        .from('lobby_players')
        .update({ is_reserve: false })
        .eq('id', reservas[0].id)
    }

    refetch()
  }

  const handleAddPlayerToLobby = async (playerNickname: string, playerPlatform: string, playerId?: string) => {
    if (!lobby) return

    // Check if reserve
    const isReserve = titulares.length >= (lobby.max_players || 10)

    if (isReserve && reservas.length >= (lobby.max_reserves || 3)) {
      alert('Lobby e reservas estao cheios')
      return
    }

    await supabase
      .from('lobby_players')
      .insert({
        lobby_id: lobby.id,
        player_id: playerId || null,
        nickname: playerNickname,
        platform: playerPlatform,
        is_reserve: isReserve,
      })

    setSearchTerm('')
    setShowAddPlayer(false)
    refetch()
  }

  const handleAddNewPlayerToLobby = async () => {
    if (!searchTerm.trim() || !lobby) return

    // Check if player exists in database
    let { data: existingPlayer } = await supabase
      .from('players')
      .select('id, nickname, platform')
      .ilike('nickname', searchTerm.trim())
      .single()

    if (!existingPlayer) {
      // Create new player
      const { data: newPlayer, error } = await supabase
        .from('players')
        .insert({
          nickname: searchTerm.trim(),
          platform: selectedPlatform,
        })
        .select()
        .single()

      if (error) {
        alert('Erro ao criar jogador: ' + error.message)
        return
      }
      existingPlayer = newPlayer
      refetchPlayers()
    }

    await handleAddPlayerToLobby(
      existingPlayer.nickname,
      existingPlayer.platform,
      existingPlayer.id
    )
  }

  const handleStartDraw = async () => {
    if (!lobby || titulares.length < 10) {
      alert('Precisa de 10 jogadores para iniciar o sorteio')
      return
    }

    setIsDrawing(true)

    // Get player ELOs for balancing
    const playerWithElos = await Promise.all(
      titulares.map(async (lp) => {
        if (lp.player_id) {
          const { data } = await supabase
            .from('players')
            .select('elo')
            .eq('id', lp.player_id)
            .single()
          return { ...lp, elo: data?.elo || 1000 }
        }
        return { ...lp, elo: 1000 }
      })
    )

    // Balance teams based on ELO
    const { teamA, teamB } = balanceTeams(
      playerWithElos.map(p => ({
        nickname: p.nickname,
        platform: p.platform,
        elo: p.elo,
        player_id: p.player_id
      }))
    )

    // Random sides
    const teamASide = Math.random() > 0.5 ? 'ATAQUE' : 'DEFESA'
    const teamBSide = teamASide === 'ATAQUE' ? 'DEFESA' : 'ATAQUE'

    // Random map
    const randomMap = activeMaps[Math.floor(Math.random() * activeMaps.length)]

    // Create match
    const { data: match, error: matchError } = await supabase
      .from('matches')
      .insert({
        map_id: randomMap?.id,
        team_a_side: teamASide,
        team_b_side: teamBSide,
        status: 'pending',
      })
      .select()
      .single()

    if (match) {
      // Add match players with their player_ids
      const matchPlayers = [
        ...teamA.map(p => ({
          match_id: match.id,
          player_id: (p as any).player_id,
          team: 'TEAM_A' as const,
        })),
        ...teamB.map(p => ({
          match_id: match.id,
          player_id: (p as any).player_id,
          team: 'TEAM_B' as const,
        }))
      ]

      await supabase.from('match_players').insert(matchPlayers)

      // Save draw result with ELO info
      await supabase.from('draw_results').insert({
        lobby_id: lobby.id,
        match_id: match.id,
        map_id: randomMap?.id,
        team_a_players: teamA.map(p => ({ 
          nickname: p.nickname, 
          platform: p.platform,
          elo: p.elo 
        })),
        team_b_players: teamB.map(p => ({ 
          nickname: p.nickname, 
          platform: p.platform,
          elo: p.elo 
        })),
        team_a_side: teamASide,
        team_b_side: teamBSide,
      })

      // Close lobby
      await supabase
        .from('lobby')
        .update({ is_open: false, updated_at: new Date().toISOString() })
        .eq('id', lobby.id)
    }

    setIsDrawing(false)
    refetch()
  }

  const handleCreateNewLobby = async () => {
    // Clear existing lobby players
    if (lobby) {
      await supabase.from('lobby_players').delete().eq('lobby_id', lobby.id)
    }

    // Create new lobby
    const { data: newLobby, error } = await supabase
      .from('lobby')
      .insert({
        is_open: true,
        max_players: 10,
        max_reserves: 3,
        scheduled_datetime: new Date(Date.now() + 2 * 60 * 60 * 1000).toISOString()
      })
      .select()
      .single()

    if (!error) {
      refetch()
    }
  }

  const updateScheduledTime = async (datetime: string) => {
    if (!lobby) return

    await supabase
      .from('lobby')
      .update({ scheduled_datetime: new Date(datetime).toISOString() })
      .eq('id', lobby.id)

    refetch()
  }

  return (
    <div className="space-y-6">
      {/* Lobby Controls */}
      <GlowCard>
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
          <div>
            <h3 className="text-xl font-bold mb-1">Controle do Lobby</h3>
            <p className="text-sm text-muted-foreground">
              {lobby ? (lobby.is_open ? 'Lobby aberto' : 'Lobby fechado') : 'Nenhum lobby ativo'}
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            {lobby ? (
              <>
                <Button
                  onClick={handleToggleLobby}
                  variant={lobby.is_open ? 'destructive' : 'default'}
                  className={cn(!lobby.is_open && "bg-green-500 hover:bg-green-600")}
                >
                  {lobby.is_open ? (
                    <>
                      <Pause className="w-4 h-4 mr-2" />
                      Fechar Lobby
                    </>
                  ) : (
                    <>
                      <Play className="w-4 h-4 mr-2" />
                      Abrir Lobby
                    </>
                  )}
                </Button>
                <Button onClick={handleResetLobby} variant="outline">
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Resetar
                </Button>
              </>
            ) : (
              <Button onClick={handleCreateNewLobby} className="bg-primary text-primary-foreground">
                <Play className="w-4 h-4 mr-2" />
                Criar Lobby
              </Button>
            )}
          </div>
        </div>

        {lobby && (
          <>
            {/* Schedule */}
            <div className="flex items-center gap-4 mb-6 p-4 bg-secondary/50 rounded-lg">
              <Clock className="w-5 h-5 text-primary" />
              <div className="flex-1">
                <p className="text-sm text-muted-foreground mb-1">Data e Hora do Lobby</p>
                <Input
                  type="datetime-local"
                  defaultValue={lobby.scheduled_datetime ? new Date(lobby.scheduled_datetime).toISOString().slice(0, 16) : ''}
                  onChange={(e) => updateScheduledTime(e.target.value)}
                  className="max-w-xs"
                />
              </div>
            </div>

            {/* Slots */}
            <div className="text-center py-6 bg-secondary/30 rounded-lg mb-6">
              <div className="text-5xl font-black text-primary mb-2">
                {titulares.length}/{lobby.max_players}
              </div>
              <p className="text-muted-foreground">Jogadores no Lobby</p>
              {reservas.length > 0 && (
                <p className="text-sm text-muted-foreground mt-1">+ {reservas.length} reservas</p>
              )}
            </div>

            {/* Add Player Section */}
            <div className="mb-6">
              <Button
                onClick={() => setShowAddPlayer(!showAddPlayer)}
                variant="outline"
                className="w-full mb-4"
              >
                <UserPlus className="w-4 h-4 mr-2" />
                Adicionar Jogador ao Lobby
              </Button>

              {showAddPlayer && (
                <div className="glass-dark rounded-lg p-4 space-y-4">
                  <div className="flex gap-2">
                    <div className="relative flex-1">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                      <Input
                        type="text"
                        placeholder="Buscar ou criar jogador..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10"
                      />
                    </div>
                    <select
                      value={selectedPlatform}
                      onChange={(e) => setSelectedPlatform(e.target.value as 'PC' | 'Xbox' | 'PSN')}
                      className="px-3 py-2 rounded-lg bg-secondary border border-border"
                    >
                      <option value="PC">PC</option>
                      <option value="Xbox">Xbox</option>
                      <option value="PSN">PSN</option>
                    </select>
                  </div>

                  {/* Existing players list */}
                  {searchTerm && availablePlayers.length > 0 && (
                    <div className="max-h-48 overflow-y-auto space-y-2">
                      {availablePlayers.slice(0, 10).map(player => (
                        <div
                          key={player.id}
                          className="flex items-center justify-between p-2 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors cursor-pointer"
                          onClick={() => handleAddPlayerToLobby(player.nickname, player.platform, player.id)}
                        >
                          <div className="flex items-center gap-3">
                            <span className="font-medium">{player.nickname}</span>
                            <RankBadge elo={player.elo} size="sm" />
                            <span className="text-xs text-muted-foreground">{player.platform}</span>
                          </div>
                          <UserPlus className="w-4 h-4 text-primary" />
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Add new player button */}
                  {searchTerm && (
                    <Button
                      onClick={handleAddNewPlayerToLobby}
                      className="w-full"
                    >
                      <UserPlus className="w-4 h-4 mr-2" />
                      Adicionar &quot;{searchTerm}&quot; como novo jogador ({selectedPlatform})
                    </Button>
                  )}
                </div>
              )}
            </div>

            {/* Draw Button */}
            {titulares.length >= 10 && (
              <Button
                onClick={handleStartDraw}
                disabled={isDrawing}
                className="w-full bg-primary text-primary-foreground glow-yellow mb-6 py-6 text-lg"
              >
                {isDrawing ? (
                  <>
                    <RefreshCw className="w-5 h-5 mr-2 animate-spin" />
                    Sorteando (Balanceado)...
                  </>
                ) : (
                  <>
                    <Shuffle className="w-5 h-5 mr-2" />
                    INICIAR SORTEIO BALANCEADO
                  </>
                )}
              </Button>
            )}
          </>
        )}
      </GlowCard>

      {/* Players in Lobby */}
      {lobby && (
        <GlowCard>
          <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
            <Users className="w-5 h-5 text-primary" />
            Jogadores Titulares ({titulares.length}/{lobby.max_players})
          </h3>
          
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mb-6">
            {Array.from({ length: lobby.max_players }).map((_, i) => {
              const player = titulares[i]
              const playerData = player ? allPlayers.find(p => p.id === player.player_id) : null
              return (
                <div
                  key={i}
                  className={cn(
                    "glass-dark rounded-lg p-3 text-center relative",
                    player && "border border-primary/30"
                  )}
                >
                  {player ? (
                    <>
                      <button
                        onClick={() => handleRemovePlayer(player.id)}
                        className="absolute top-1 right-1 p-1 text-muted-foreground hover:text-destructive transition-colors"
                      >
                        <UserMinus className="w-4 h-4" />
                      </button>
                      <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-2">
                        <span className="font-bold text-primary text-sm">
                          {player.nickname.charAt(0).toUpperCase()}
                        </span>
                      </div>
                      <p className="text-sm font-medium truncate">{player.nickname}</p>
                      <p className="text-xs text-muted-foreground">{player.platform}</p>
                      {playerData && (
                        <div className="mt-1">
                          <RankBadge elo={playerData.elo} size="sm" />
                        </div>
                      )}
                    </>
                  ) : (
                    <>
                      <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center mx-auto mb-2">
                        <span className="text-muted-foreground text-sm">{i + 1}</span>
                      </div>
                      <p className="text-xs text-muted-foreground">Vago</p>
                    </>
                  )}
                </div>
              )
            })}
          </div>

          {/* Reserves */}
          {lobby.max_reserves > 0 && (
            <>
              <h3 className="text-lg font-bold mb-4">
                Reservas ({reservas.length}/{lobby.max_reserves})
              </h3>
              <div className="grid grid-cols-3 gap-3">
                {Array.from({ length: lobby.max_reserves }).map((_, i) => {
                  const player = reservas[i]
                  const playerData = player ? allPlayers.find(p => p.id === player.player_id) : null
                  return (
                    <div
                      key={i}
                      className={cn(
                        "glass-dark rounded-lg p-3 text-center relative",
                        player && "border border-orange-500/30"
                      )}
                    >
                      {player ? (
                        <>
                          <button
                            onClick={() => handleRemovePlayer(player.id)}
                            className="absolute top-1 right-1 p-1 text-muted-foreground hover:text-destructive transition-colors"
                          >
                            <UserMinus className="w-4 h-4" />
                          </button>
                          <p className="text-sm font-medium truncate">{player.nickname}</p>
                          <p className="text-xs text-muted-foreground">{player.platform}</p>
                          {playerData && (
                            <div className="mt-1">
                              <RankBadge elo={playerData.elo} size="sm" />
                            </div>
                          )}
                        </>
                      ) : (
                        <p className="text-xs text-muted-foreground py-2">Reserva {i + 1}</p>
                      )}
                    </div>
                  )
                })}
              </div>
            </>
          )}
        </GlowCard>
      )}
    </div>
  )
}
