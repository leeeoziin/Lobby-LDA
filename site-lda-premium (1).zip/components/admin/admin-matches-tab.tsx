'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  Plus, 
  Edit, 
  Trash2, 
  Save,
  X,
  ChevronUp,
  ChevronDown,
  Trophy,
  MapPin,
  Image as ImageIcon,
  Play,
  CheckCircle,
  Search,
  UserPlus
} from 'lucide-react'
import { useMatches, useMaps, usePlayers, useSeasons } from '@/hooks/use-supabase'
import { createClient } from '@/lib/supabase/client'
import { GlowCard } from '@/components/ui/glow-card'
import { RankBadge } from '@/components/ui/rank-badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { cn } from '@/lib/utils'
import type { Match, MatchPlayer, Player } from '@/lib/types/database'

const supabase = createClient()

// ELO changes based on result
const ELO_WIN = 100
const ELO_WIN_OT = 60
const ELO_LOSS_OT = -30
const ELO_LOSS = -60

// Points based on result
const POINTS_WIN = 3
const POINTS_WIN_OT = 2
const POINTS_LOSS_OT = 1
const POINTS_LOSS = 0

interface NewMatchPlayer {
  id: string
  nickname: string
  team: 'TEAM_A' | 'TEAM_B'
  kills: number
  deaths: number
  assists: number
  player_id?: string
}

export function AdminMatchesTab() {
  const { matches, loading, refetch } = useMatches()
  const { maps } = useMaps()
  const { players, refetch: refetchPlayers } = usePlayers()
  const { activeSeason } = useSeasons()
  const [editingMatch, setEditingMatch] = useState<Match | null>(null)
  const [editingPlayers, setEditingPlayers] = useState<MatchPlayer[]>([])
  const [showAddForm, setShowAddForm] = useState(false)
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedTeam, setSelectedTeam] = useState<'TEAM_A' | 'TEAM_B'>('TEAM_A')

  // New match form state
  const [newMatch, setNewMatch] = useState({
    map_id: '',
    team_a_score: 0,
    team_b_score: 0,
    team_a_side: 'ATAQUE' as 'ATAQUE' | 'DEFESA',
    match_date: new Date().toISOString().slice(0, 16),
    image_url: '',
    status: 'finished' as 'pending' | 'in_progress' | 'finished'
  })
  const [newMatchPlayers, setNewMatchPlayers] = useState<NewMatchPlayer[]>([])

  const handleUpdateMatch = async () => {
    if (!editingMatch) return

    const isOvertime = Math.abs(editingMatch.team_a_score - editingMatch.team_b_score) === 1 &&
                       (editingMatch.team_a_score >= 7 || editingMatch.team_b_score >= 7)

    const winner = editingMatch.team_a_score > editingMatch.team_b_score ? 'TEAM_A' : 
                   editingMatch.team_b_score > editingMatch.team_a_score ? 'TEAM_B' : null

    // Update match
    await supabase
      .from('matches')
      .update({
        team_a_score: editingMatch.team_a_score,
        team_b_score: editingMatch.team_b_score,
        map_id: editingMatch.map_id,
        mvp_player_id: editingMatch.mvp_player_id,
        status: editingMatch.status,
        image_url: editingMatch.image_url,
        winner,
        is_overtime: isOvertime,
        updated_at: new Date().toISOString()
      })
      .eq('id', editingMatch.id)

    // Update match players stats
    for (const mp of editingPlayers) {
      await supabase
        .from('match_players')
        .update({
          kills: mp.kills,
          deaths: mp.deaths,
          assists: mp.assists,
          entry_kills: mp.entry_kills,
          clutches: mp.clutches,
          is_mvp: mp.player_id === editingMatch.mvp_player_id
        })
        .eq('id', mp.id)

      // Update player global stats if match is finished
      if (editingMatch.status === 'finished' && mp.player_id) {
        const player = players.find(p => p.id === mp.player_id)
        if (player) {
          const isWinner = (winner === 'TEAM_A' && mp.team === 'TEAM_A') ||
                          (winner === 'TEAM_B' && mp.team === 'TEAM_B')
          
          let eloChange = 0
          let pointsChange = 0
          let winsChange = 0
          let winsOtChange = 0
          let lossesOtChange = 0
          let lossesChange = 0

          if (isWinner) {
            if (isOvertime) {
              eloChange = ELO_WIN_OT
              pointsChange = POINTS_WIN_OT
              winsOtChange = 1
            } else {
              eloChange = ELO_WIN
              pointsChange = POINTS_WIN
              winsChange = 1
            }
          } else {
            if (isOvertime) {
              eloChange = ELO_LOSS_OT
              pointsChange = POINTS_LOSS_OT
              lossesOtChange = 1
            } else {
              eloChange = ELO_LOSS
              pointsChange = POINTS_LOSS
              lossesChange = 1
            }
          }

          // Calculate new averages
          const newKills = player.kills + mp.kills
          const newDeaths = player.deaths + mp.deaths
          const newAssists = player.assists + mp.assists
          const newMatches = player.matches_played + 1

          await supabase
            .from('players')
            .update({
              elo: Math.max(0, player.elo + eloChange),
              points: player.points + pointsChange,
              kills: newKills,
              deaths: newDeaths,
              assists: newAssists,
              matches_played: newMatches,
              wins: player.wins + winsChange,
              wins_ot: player.wins_ot + winsOtChange,
              losses_ot: player.losses_ot + lossesOtChange,
              losses: player.losses + lossesChange,
              mvp_count: mp.player_id === editingMatch.mvp_player_id ? player.mvp_count + 1 : player.mvp_count,
              current_streak: isWinner ? Math.max(1, player.current_streak + 1) : Math.min(-1, player.current_streak - 1),
              updated_at: new Date().toISOString()
            })
            .eq('id', player.id)
        }
      }
    }

    setEditingMatch(null)
    setEditingPlayers([])
    refetch()
    refetchPlayers()
  }

  const handleDeleteMatch = async (matchId: string) => {
    if (!confirm('Tem certeza que deseja excluir esta partida?')) return

    await supabase.from('match_players').delete().eq('match_id', matchId)
    await supabase.from('matches').delete().eq('id', matchId)

    refetch()
  }

  const startEditing = (match: Match) => {
    setEditingMatch(match)
    setEditingPlayers(match.match_players || [])
  }

  const updatePlayerStat = (playerId: string, field: keyof MatchPlayer, value: number) => {
    setEditingPlayers(prev => 
      prev.map(p => p.id === playerId ? { ...p, [field]: value } : p)
    )
  }

  // New match functions
  const addPlayerToNewMatch = async (playerNickname: string, team: 'TEAM_A' | 'TEAM_B') => {
    // Check if player exists
    let existingPlayer = players.find(p => p.nickname.toLowerCase() === playerNickname.toLowerCase())
    
    if (!existingPlayer) {
      // Create new player
      const { data: newPlayer, error } = await supabase
        .from('players')
        .insert({ nickname: playerNickname, platform: 'PC' })
        .select()
        .single()
      
      if (error) {
        alert('Erro ao criar jogador: ' + error.message)
        return
      }
      existingPlayer = newPlayer
      refetchPlayers()
    }

    // Check if already added
    if (newMatchPlayers.find(p => p.player_id === existingPlayer?.id)) {
      alert('Jogador ja adicionado')
      return
    }

    // Check team limit
    const teamPlayers = newMatchPlayers.filter(p => p.team === team)
    if (teamPlayers.length >= 5) {
      alert('Time ja tem 5 jogadores')
      return
    }

    setNewMatchPlayers(prev => [...prev, {
      id: crypto.randomUUID(),
      nickname: existingPlayer!.nickname,
      team,
      kills: 0,
      deaths: 0,
      assists: 0,
      player_id: existingPlayer!.id
    }])

    setSearchTerm('')
  }

  const updateNewMatchPlayerStat = (id: string, field: keyof NewMatchPlayer, value: number | string) => {
    setNewMatchPlayers(prev =>
      prev.map(p => p.id === id ? { ...p, [field]: value } : p)
    )
  }

  const removeNewMatchPlayer = (id: string) => {
    setNewMatchPlayers(prev => prev.filter(p => p.id !== id))
  }

  const handleCreateMatch = async () => {
    if (!newMatch.map_id) {
      alert('Selecione um mapa')
      return
    }

    if (newMatchPlayers.filter(p => p.team === 'TEAM_A').length !== 5 ||
        newMatchPlayers.filter(p => p.team === 'TEAM_B').length !== 5) {
      alert('Cada time precisa ter 5 jogadores')
      return
    }

    const isOvertime = Math.abs(newMatch.team_a_score - newMatch.team_b_score) === 1 &&
                       (newMatch.team_a_score >= 7 || newMatch.team_b_score >= 7)

    const winner = newMatch.team_a_score > newMatch.team_b_score ? 'TEAM_A' : 
                   newMatch.team_b_score > newMatch.team_a_score ? 'TEAM_B' : null

    // Determine MVP (player with most kills)
    const allPlayers = [...newMatchPlayers]
    allPlayers.sort((a, b) => b.kills - a.kills)
    const mvpPlayerId = allPlayers[0]?.player_id

    // Create match
    const { data: match, error: matchError } = await supabase
      .from('matches')
      .insert({
        season_id: activeSeason?.id,
        map_id: newMatch.map_id,
        team_a_score: newMatch.team_a_score,
        team_b_score: newMatch.team_b_score,
        team_a_side: newMatch.team_a_side,
        team_b_side: newMatch.team_a_side === 'ATAQUE' ? 'DEFESA' : 'ATAQUE',
        mvp_player_id: mvpPlayerId,
        winner,
        is_overtime: isOvertime,
        status: newMatch.status,
        image_url: newMatch.image_url || null,
        match_date: new Date(newMatch.match_date).toISOString()
      })
      .select()
      .single()

    if (matchError) {
      alert('Erro ao criar partida: ' + matchError.message)
      return
    }

    // Add match players
    const matchPlayersData = newMatchPlayers.map(mp => ({
      match_id: match.id,
      player_id: mp.player_id,
      team: mp.team,
      kills: mp.kills,
      deaths: mp.deaths,
      assists: mp.assists,
      is_mvp: mp.player_id === mvpPlayerId
    }))

    await supabase.from('match_players').insert(matchPlayersData)

    // Update player stats if match is finished
    if (newMatch.status === 'finished') {
      for (const mp of newMatchPlayers) {
        const player = players.find(p => p.id === mp.player_id)
        if (!player) continue

        const isWinner = (winner === 'TEAM_A' && mp.team === 'TEAM_A') ||
                        (winner === 'TEAM_B' && mp.team === 'TEAM_B')
        
        let eloChange = 0
        let pointsChange = 0
        let winsChange = 0
        let winsOtChange = 0
        let lossesOtChange = 0
        let lossesChange = 0

        if (isWinner) {
          if (isOvertime) {
            eloChange = ELO_WIN_OT
            pointsChange = POINTS_WIN_OT
            winsOtChange = 1
          } else {
            eloChange = ELO_WIN
            pointsChange = POINTS_WIN
            winsChange = 1
          }
        } else {
          if (isOvertime) {
            eloChange = ELO_LOSS_OT
            pointsChange = POINTS_LOSS_OT
            lossesOtChange = 1
          } else {
            eloChange = ELO_LOSS
            pointsChange = POINTS_LOSS
            lossesChange = 1
          }
        }

        await supabase
          .from('players')
          .update({
            elo: Math.max(0, player.elo + eloChange),
            points: player.points + pointsChange,
            kills: player.kills + mp.kills,
            deaths: player.deaths + mp.deaths,
            assists: player.assists + mp.assists,
            matches_played: player.matches_played + 1,
            wins: player.wins + winsChange,
            wins_ot: player.wins_ot + winsOtChange,
            losses_ot: player.losses_ot + lossesOtChange,
            losses: player.losses + lossesChange,
            mvp_count: mp.player_id === mvpPlayerId ? player.mvp_count + 1 : player.mvp_count,
            current_streak: isWinner ? Math.max(1, player.current_streak + 1) : Math.min(-1, player.current_streak - 1),
            updated_at: new Date().toISOString()
          })
          .eq('id', player.id)
      }
    }

    // Reset form
    setShowAddForm(false)
    setNewMatch({
      map_id: '',
      team_a_score: 0,
      team_b_score: 0,
      team_a_side: 'ATAQUE',
      match_date: new Date().toISOString().slice(0, 16),
      image_url: '',
      status: 'finished'
    })
    setNewMatchPlayers([])
    
    refetch()
    refetchPlayers()
  }

  const teamAPlayers = newMatchPlayers.filter(p => p.team === 'TEAM_A')
  const teamBPlayers = newMatchPlayers.filter(p => p.team === 'TEAM_B')
  const filteredPlayers = players.filter(p => 
    p.nickname.toLowerCase().includes(searchTerm.toLowerCase()) &&
    !newMatchPlayers.find(mp => mp.player_id === p.id)
  )

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-bold">Partidas ({matches.length})</h3>
        <Button 
          onClick={() => setShowAddForm(!showAddForm)}
          className="bg-primary text-primary-foreground"
        >
          <Plus className="w-4 h-4 mr-2" />
          Adicionar Partida
        </Button>
      </div>

      {/* Add Match Form */}
      <AnimatePresence>
        {showAddForm && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
          >
            <GlowCard className="border border-primary/50">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold">Adicionar Partida Ja Jogada</h3>
                <Button variant="ghost" size="sm" onClick={() => setShowAddForm(false)}>
                  <X className="w-4 h-4" />
                </Button>
              </div>

              {/* Match Info */}
              <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                <div>
                  <label className="text-sm text-muted-foreground mb-1 block">Mapa *</label>
                  <select
                    value={newMatch.map_id}
                    onChange={(e) => setNewMatch({ ...newMatch, map_id: e.target.value })}
                    className="w-full p-2 rounded-lg bg-secondary border border-border"
                  >
                    <option value="">Selecione...</option>
                    {maps.filter(m => m.is_active).map(m => (
                      <option key={m.id} value={m.id}>{m.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-sm text-muted-foreground mb-1 block">Data/Hora</label>
                  <Input
                    type="datetime-local"
                    value={newMatch.match_date}
                    onChange={(e) => setNewMatch({ ...newMatch, match_date: e.target.value })}
                  />
                </div>
                <div>
                  <label className="text-sm text-muted-foreground mb-1 block">Lado Time A</label>
                  <select
                    value={newMatch.team_a_side}
                    onChange={(e) => setNewMatch({ ...newMatch, team_a_side: e.target.value as 'ATAQUE' | 'DEFESA' })}
                    className="w-full p-2 rounded-lg bg-secondary border border-border"
                  >
                    <option value="ATAQUE">Ataque</option>
                    <option value="DEFESA">Defesa</option>
                  </select>
                </div>
                <div>
                  <label className="text-sm text-muted-foreground mb-1 block">Status</label>
                  <select
                    value={newMatch.status}
                    onChange={(e) => setNewMatch({ ...newMatch, status: e.target.value as any })}
                    className="w-full p-2 rounded-lg bg-secondary border border-border"
                  >
                    <option value="finished">Finalizada</option>
                    <option value="in_progress">Em andamento</option>
                    <option value="pending">Pendente</option>
                  </select>
                </div>
              </div>

              {/* Score */}
              <div className="flex items-center justify-center gap-8 mb-6 p-4 bg-secondary/30 rounded-lg">
                <div className="text-center">
                  <p className="text-sm text-muted-foreground mb-2">TIME A</p>
                  <div className="flex items-center gap-2">
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => setNewMatch({ ...newMatch, team_a_score: Math.max(0, newMatch.team_a_score - 1) })}
                    >
                      <ChevronDown className="w-4 h-4" />
                    </Button>
                    <span className="text-4xl font-black w-12 text-center">{newMatch.team_a_score}</span>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => setNewMatch({ ...newMatch, team_a_score: newMatch.team_a_score + 1 })}
                    >
                      <ChevronUp className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
                <span className="text-2xl text-muted-foreground font-bold">x</span>
                <div className="text-center">
                  <p className="text-sm text-muted-foreground mb-2">TIME B</p>
                  <div className="flex items-center gap-2">
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => setNewMatch({ ...newMatch, team_b_score: Math.max(0, newMatch.team_b_score - 1) })}
                    >
                      <ChevronDown className="w-4 h-4" />
                    </Button>
                    <span className="text-4xl font-black w-12 text-center">{newMatch.team_b_score}</span>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => setNewMatch({ ...newMatch, team_b_score: newMatch.team_b_score + 1 })}
                    >
                      <ChevronUp className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>

              {/* Image URL */}
              <div className="mb-6">
                <label className="text-sm text-muted-foreground mb-1 block">URL da Imagem/Screenshot (opcional)</label>
                <Input
                  value={newMatch.image_url}
                  onChange={(e) => setNewMatch({ ...newMatch, image_url: e.target.value })}
                  placeholder="https://..."
                />
              </div>

              {/* Add Players */}
              <div className="mb-6">
                <label className="text-sm text-muted-foreground mb-2 block">Adicionar Jogadores</label>
                <div className="flex gap-2 mb-3">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input
                      type="text"
                      placeholder="Buscar jogador..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  <select
                    value={selectedTeam}
                    onChange={(e) => setSelectedTeam(e.target.value as 'TEAM_A' | 'TEAM_B')}
                    className="px-3 py-2 rounded-lg bg-secondary border border-border"
                  >
                    <option value="TEAM_A">Time A ({teamAPlayers.length}/5)</option>
                    <option value="TEAM_B">Time B ({teamBPlayers.length}/5)</option>
                  </select>
                </div>

                {/* Search Results */}
                {searchTerm && (
                  <div className="max-h-40 overflow-y-auto space-y-1 mb-4">
                    {filteredPlayers.slice(0, 8).map(player => (
                      <div
                        key={player.id}
                        className="flex items-center justify-between p-2 rounded-lg bg-secondary/50 hover:bg-secondary cursor-pointer"
                        onClick={() => addPlayerToNewMatch(player.nickname, selectedTeam)}
                      >
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{player.nickname}</span>
                          <RankBadge elo={player.elo} size="sm" />
                        </div>
                        <UserPlus className="w-4 h-4 text-primary" />
                      </div>
                    ))}
                    {searchTerm && !players.find(p => p.nickname.toLowerCase() === searchTerm.toLowerCase()) && (
                      <div
                        className="flex items-center justify-between p-2 rounded-lg bg-primary/10 hover:bg-primary/20 cursor-pointer border border-dashed border-primary/50"
                        onClick={() => addPlayerToNewMatch(searchTerm, selectedTeam)}
                      >
                        <span className="text-primary">Criar &quot;{searchTerm}&quot; como novo jogador</span>
                        <UserPlus className="w-4 h-4 text-primary" />
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Teams */}
              <div className="grid md:grid-cols-2 gap-6 mb-6">
                {/* Team A */}
                <div className="glass-dark rounded-lg p-4">
                  <h4 className="font-bold mb-3 flex items-center justify-between">
                    <span>TIME A ({teamAPlayers.length}/5)</span>
                    <span className={cn(
                      "text-xs px-2 py-1 rounded-full",
                      newMatch.team_a_side === 'ATAQUE' ? "bg-red-500/20 text-red-500" : "bg-blue-500/20 text-blue-500"
                    )}>
                      {newMatch.team_a_side}
                    </span>
                  </h4>
                  <div className="space-y-2">
                    {teamAPlayers.map(mp => (
                      <div key={mp.id} className="bg-secondary/50 rounded-lg p-2">
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-medium text-sm">{mp.nickname}</span>
                          <button
                            onClick={() => removeNewMatchPlayer(mp.id)}
                            className="text-muted-foreground hover:text-destructive"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                        <div className="grid grid-cols-3 gap-2 text-xs">
                          <div>
                            <span className="text-muted-foreground">K</span>
                            <div className="flex items-center gap-1">
                              <button className="text-muted-foreground hover:text-foreground" onClick={() => updateNewMatchPlayerStat(mp.id, 'kills', Math.max(0, mp.kills - 1))}>-</button>
                              <span className="text-green-500 font-bold w-6 text-center">{mp.kills}</span>
                              <button className="text-muted-foreground hover:text-foreground" onClick={() => updateNewMatchPlayerStat(mp.id, 'kills', mp.kills + 1)}>+</button>
                            </div>
                          </div>
                          <div>
                            <span className="text-muted-foreground">D</span>
                            <div className="flex items-center gap-1">
                              <button className="text-muted-foreground hover:text-foreground" onClick={() => updateNewMatchPlayerStat(mp.id, 'deaths', Math.max(0, mp.deaths - 1))}>-</button>
                              <span className="text-red-500 font-bold w-6 text-center">{mp.deaths}</span>
                              <button className="text-muted-foreground hover:text-foreground" onClick={() => updateNewMatchPlayerStat(mp.id, 'deaths', mp.deaths + 1)}>+</button>
                            </div>
                          </div>
                          <div>
                            <span className="text-muted-foreground">A</span>
                            <div className="flex items-center gap-1">
                              <button className="text-muted-foreground hover:text-foreground" onClick={() => updateNewMatchPlayerStat(mp.id, 'assists', Math.max(0, mp.assists - 1))}>-</button>
                              <span className="text-blue-500 font-bold w-6 text-center">{mp.assists}</span>
                              <button className="text-muted-foreground hover:text-foreground" onClick={() => updateNewMatchPlayerStat(mp.id, 'assists', mp.assists + 1)}>+</button>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                    {teamAPlayers.length === 0 && (
                      <p className="text-sm text-muted-foreground text-center py-4">Adicione jogadores</p>
                    )}
                  </div>
                </div>

                {/* Team B */}
                <div className="glass-dark rounded-lg p-4">
                  <h4 className="font-bold mb-3 flex items-center justify-between">
                    <span>TIME B ({teamBPlayers.length}/5)</span>
                    <span className={cn(
                      "text-xs px-2 py-1 rounded-full",
                      newMatch.team_a_side === 'ATAQUE' ? "bg-blue-500/20 text-blue-500" : "bg-red-500/20 text-red-500"
                    )}>
                      {newMatch.team_a_side === 'ATAQUE' ? 'DEFESA' : 'ATAQUE'}
                    </span>
                  </h4>
                  <div className="space-y-2">
                    {teamBPlayers.map(mp => (
                      <div key={mp.id} className="bg-secondary/50 rounded-lg p-2">
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-medium text-sm">{mp.nickname}</span>
                          <button
                            onClick={() => removeNewMatchPlayer(mp.id)}
                            className="text-muted-foreground hover:text-destructive"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                        <div className="grid grid-cols-3 gap-2 text-xs">
                          <div>
                            <span className="text-muted-foreground">K</span>
                            <div className="flex items-center gap-1">
                              <button className="text-muted-foreground hover:text-foreground" onClick={() => updateNewMatchPlayerStat(mp.id, 'kills', Math.max(0, mp.kills - 1))}>-</button>
                              <span className="text-green-500 font-bold w-6 text-center">{mp.kills}</span>
                              <button className="text-muted-foreground hover:text-foreground" onClick={() => updateNewMatchPlayerStat(mp.id, 'kills', mp.kills + 1)}>+</button>
                            </div>
                          </div>
                          <div>
                            <span className="text-muted-foreground">D</span>
                            <div className="flex items-center gap-1">
                              <button className="text-muted-foreground hover:text-foreground" onClick={() => updateNewMatchPlayerStat(mp.id, 'deaths', Math.max(0, mp.deaths - 1))}>-</button>
                              <span className="text-red-500 font-bold w-6 text-center">{mp.deaths}</span>
                              <button className="text-muted-foreground hover:text-foreground" onClick={() => updateNewMatchPlayerStat(mp.id, 'deaths', mp.deaths + 1)}>+</button>
                            </div>
                          </div>
                          <div>
                            <span className="text-muted-foreground">A</span>
                            <div className="flex items-center gap-1">
                              <button className="text-muted-foreground hover:text-foreground" onClick={() => updateNewMatchPlayerStat(mp.id, 'assists', Math.max(0, mp.assists - 1))}>-</button>
                              <span className="text-blue-500 font-bold w-6 text-center">{mp.assists}</span>
                              <button className="text-muted-foreground hover:text-foreground" onClick={() => updateNewMatchPlayerStat(mp.id, 'assists', mp.assists + 1)}>+</button>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                    {teamBPlayers.length === 0 && (
                      <p className="text-sm text-muted-foreground text-center py-4">Adicione jogadores</p>
                    )}
                  </div>
                </div>
              </div>

              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setShowAddForm(false)}>
                  Cancelar
                </Button>
                <Button 
                  onClick={handleCreateMatch}
                  className="bg-primary text-primary-foreground"
                  disabled={teamAPlayers.length !== 5 || teamBPlayers.length !== 5 || !newMatch.map_id}
                >
                  <Save className="w-4 h-4 mr-2" />
                  Criar Partida
                </Button>
              </div>
            </GlowCard>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Matches List */}
      <div className="space-y-4">
        {matches.map((match) => (
          <motion.div key={match.id} layout>
            {editingMatch?.id === match.id ? (
              <GlowCard className="border border-primary/50">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-bold">Editando Partida</h3>
                  <Button variant="ghost" size="sm" onClick={() => setEditingMatch(null)}>
                    <X className="w-4 h-4" />
                  </Button>
                </div>

                {/* Match Info */}
                <div className="grid sm:grid-cols-3 gap-4 mb-6">
                  <div>
                    <label className="text-sm text-muted-foreground mb-1 block">Mapa</label>
                    <select
                      value={editingMatch.map_id || ''}
                      onChange={(e) => setEditingMatch({ ...editingMatch, map_id: e.target.value })}
                      className="w-full p-2 rounded-lg bg-secondary border border-border"
                    >
                      {maps.map(m => (
                        <option key={m.id} value={m.id}>{m.name}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="text-sm text-muted-foreground mb-1 block">Status</label>
                    <select
                      value={editingMatch.status}
                      onChange={(e) => setEditingMatch({ ...editingMatch, status: e.target.value as Match['status'] })}
                      className="w-full p-2 rounded-lg bg-secondary border border-border"
                    >
                      <option value="pending">Pendente</option>
                      <option value="in_progress">Em andamento</option>
                      <option value="finished">Finalizada</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-sm text-muted-foreground mb-1 block">MVP</label>
                    <select
                      value={editingMatch.mvp_player_id || ''}
                      onChange={(e) => setEditingMatch({ ...editingMatch, mvp_player_id: e.target.value || null })}
                      className="w-full p-2 rounded-lg bg-secondary border border-border"
                    >
                      <option value="">Selecione...</option>
                      {editingPlayers.map(mp => (
                        <option key={mp.player_id} value={mp.player_id || ''}>
                          {mp.player?.nickname}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Score */}
                <div className="flex items-center justify-center gap-8 mb-6">
                  <div className="text-center">
                    <p className="text-sm text-muted-foreground mb-2">TIME A</p>
                    <div className="flex items-center gap-2">
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => setEditingMatch({ ...editingMatch, team_a_score: Math.max(0, editingMatch.team_a_score - 1) })}
                      >
                        <ChevronDown className="w-4 h-4" />
                      </Button>
                      <span className="text-4xl font-black w-12 text-center">{editingMatch.team_a_score}</span>
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => setEditingMatch({ ...editingMatch, team_a_score: editingMatch.team_a_score + 1 })}
                      >
                        <ChevronUp className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                  <span className="text-2xl text-muted-foreground">x</span>
                  <div className="text-center">
                    <p className="text-sm text-muted-foreground mb-2">TIME B</p>
                    <div className="flex items-center gap-2">
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => setEditingMatch({ ...editingMatch, team_b_score: Math.max(0, editingMatch.team_b_score - 1) })}
                      >
                        <ChevronDown className="w-4 h-4" />
                      </Button>
                      <span className="text-4xl font-black w-12 text-center">{editingMatch.team_b_score}</span>
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => setEditingMatch({ ...editingMatch, team_b_score: editingMatch.team_b_score + 1 })}
                      >
                        <ChevronUp className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>

                {/* Image URL */}
                <div className="mb-6">
                  <label className="text-sm text-muted-foreground mb-1 block">URL da Imagem/Screenshot</label>
                  <Input
                    value={editingMatch.image_url || ''}
                    onChange={(e) => setEditingMatch({ ...editingMatch, image_url: e.target.value })}
                    placeholder="https://..."
                  />
                </div>

                {/* Players Stats */}
                <div className="grid md:grid-cols-2 gap-6">
                  {/* Team A */}
                  <div>
                    <h4 className="font-bold mb-3">TIME A</h4>
                    <div className="space-y-3">
                      {editingPlayers.filter(p => p.team === 'TEAM_A').map(mp => (
                        <div key={mp.id} className="glass-dark rounded-lg p-3">
                          <p className="font-medium mb-2">{mp.player?.nickname}</p>
                          <div className="grid grid-cols-3 gap-2">
                            <div>
                              <label className="text-xs text-muted-foreground">Kills</label>
                              <div className="flex items-center gap-1">
                                <Button size="sm" variant="ghost" className="h-6 w-6 p-0" onClick={() => updatePlayerStat(mp.id, 'kills', Math.max(0, mp.kills - 1))}>-</Button>
                                <span className="text-green-500 font-bold w-8 text-center">{mp.kills}</span>
                                <Button size="sm" variant="ghost" className="h-6 w-6 p-0" onClick={() => updatePlayerStat(mp.id, 'kills', mp.kills + 1)}>+</Button>
                              </div>
                            </div>
                            <div>
                              <label className="text-xs text-muted-foreground">Deaths</label>
                              <div className="flex items-center gap-1">
                                <Button size="sm" variant="ghost" className="h-6 w-6 p-0" onClick={() => updatePlayerStat(mp.id, 'deaths', Math.max(0, mp.deaths - 1))}>-</Button>
                                <span className="text-red-500 font-bold w-8 text-center">{mp.deaths}</span>
                                <Button size="sm" variant="ghost" className="h-6 w-6 p-0" onClick={() => updatePlayerStat(mp.id, 'deaths', mp.deaths + 1)}>+</Button>
                              </div>
                            </div>
                            <div>
                              <label className="text-xs text-muted-foreground">Assists</label>
                              <div className="flex items-center gap-1">
                                <Button size="sm" variant="ghost" className="h-6 w-6 p-0" onClick={() => updatePlayerStat(mp.id, 'assists', Math.max(0, mp.assists - 1))}>-</Button>
                                <span className="text-blue-500 font-bold w-8 text-center">{mp.assists}</span>
                                <Button size="sm" variant="ghost" className="h-6 w-6 p-0" onClick={() => updatePlayerStat(mp.id, 'assists', mp.assists + 1)}>+</Button>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Team B */}
                  <div>
                    <h4 className="font-bold mb-3">TIME B</h4>
                    <div className="space-y-3">
                      {editingPlayers.filter(p => p.team === 'TEAM_B').map(mp => (
                        <div key={mp.id} className="glass-dark rounded-lg p-3">
                          <p className="font-medium mb-2">{mp.player?.nickname}</p>
                          <div className="grid grid-cols-3 gap-2">
                            <div>
                              <label className="text-xs text-muted-foreground">Kills</label>
                              <div className="flex items-center gap-1">
                                <Button size="sm" variant="ghost" className="h-6 w-6 p-0" onClick={() => updatePlayerStat(mp.id, 'kills', Math.max(0, mp.kills - 1))}>-</Button>
                                <span className="text-green-500 font-bold w-8 text-center">{mp.kills}</span>
                                <Button size="sm" variant="ghost" className="h-6 w-6 p-0" onClick={() => updatePlayerStat(mp.id, 'kills', mp.kills + 1)}>+</Button>
                              </div>
                            </div>
                            <div>
                              <label className="text-xs text-muted-foreground">Deaths</label>
                              <div className="flex items-center gap-1">
                                <Button size="sm" variant="ghost" className="h-6 w-6 p-0" onClick={() => updatePlayerStat(mp.id, 'deaths', Math.max(0, mp.deaths - 1))}>-</Button>
                                <span className="text-red-500 font-bold w-8 text-center">{mp.deaths}</span>
                                <Button size="sm" variant="ghost" className="h-6 w-6 p-0" onClick={() => updatePlayerStat(mp.id, 'deaths', mp.deaths + 1)}>+</Button>
                              </div>
                            </div>
                            <div>
                              <label className="text-xs text-muted-foreground">Assists</label>
                              <div className="flex items-center gap-1">
                                <Button size="sm" variant="ghost" className="h-6 w-6 p-0" onClick={() => updatePlayerStat(mp.id, 'assists', Math.max(0, mp.assists - 1))}>-</Button>
                                <span className="text-blue-500 font-bold w-8 text-center">{mp.assists}</span>
                                <Button size="sm" variant="ghost" className="h-6 w-6 p-0" onClick={() => updatePlayerStat(mp.id, 'assists', mp.assists + 1)}>+</Button>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="flex justify-end gap-2 mt-6">
                  <Button variant="outline" onClick={() => setEditingMatch(null)}>
                    Cancelar
                  </Button>
                  <Button 
                    onClick={handleUpdateMatch}
                    className="bg-primary text-primary-foreground"
                  >
                    <Save className="w-4 h-4 mr-2" />
                    Salvar e Atualizar Stats
                  </Button>
                </div>
              </GlowCard>
            ) : (
              <GlowCard className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
                <div className="flex items-center gap-3 flex-1">
                  <MapPin className="w-5 h-5 text-primary" />
                  <span className="font-medium">{match.map?.name}</span>
                  <span className={cn(
                    "px-2 py-1 rounded-full text-xs font-medium",
                    match.status === 'finished' ? 'bg-green-500/20 text-green-500' :
                    match.status === 'in_progress' ? 'bg-yellow-500/20 text-yellow-500' :
                    'bg-gray-500/20 text-gray-500'
                  )}>
                    {match.status === 'finished' ? 'Finalizada' :
                     match.status === 'in_progress' ? 'Em andamento' : 'Pendente'}
                  </span>
                  <span className="text-xs text-muted-foreground">
                    {new Date(match.match_date).toLocaleDateString('pt-BR')}
                  </span>
                </div>

                <div className="flex items-center gap-4 font-bold text-xl">
                  <span className={cn(match.winner === 'TEAM_A' && 'text-green-500')}>
                    {match.team_a_score}
                  </span>
                  <span className="text-muted-foreground">x</span>
                  <span className={cn(match.winner === 'TEAM_B' && 'text-green-500')}>
                    {match.team_b_score}
                  </span>
                </div>

                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={() => startEditing(match)}>
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleDeleteMatch(match.id)}
                    className="text-destructive hover:text-destructive"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </GlowCard>
            )}
          </motion.div>
        ))}
      </div>
    </div>
  )
}
