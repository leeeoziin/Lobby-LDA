"use client"

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { createClient } from '@/lib/supabase/client'
import { Settings, Save, Link, Bell, Clock, Key, RefreshCw } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { GlowCard } from '@/components/ui/glow-card'

interface SettingItem {
  id: string
  key: string
  value: string
  updated_at: string
}

interface Announcement {
  id: string
  title: string | null
  message: string
  type: 'lobby' | 'matchmaking' | 'general'
  is_active: boolean
}

export function AdminSettingsTab() {
  const [settings, setSettings] = useState<SettingItem[]>([])
  const [announcements, setAnnouncements] = useState<Announcement[]>([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [newAnnouncement, setNewAnnouncement] = useState({ title: '', message: '', type: 'general' as const })

  const supabase = createClient()

  useEffect(() => {
    fetchData()
  }, [])

  async function fetchData() {
    setLoading(true)
    const [settingsRes, announcementsRes] = await Promise.all([
      supabase.from('settings').select('*'),
      supabase.from('announcements').select('*').order('created_at', { ascending: false })
    ])
    
    if (settingsRes.data) setSettings(settingsRes.data)
    if (announcementsRes.data) setAnnouncements(announcementsRes.data)
    setLoading(false)
  }

  async function updateSetting(key: string, value: string) {
    setSaving(true)
    await supabase
      .from('settings')
      .update({ value, updated_at: new Date().toISOString() })
      .eq('key', key)
    
    setSettings(prev => prev.map(s => s.key === key ? { ...s, value } : s))
    setSaving(false)
  }

  async function addAnnouncement() {
    if (!newAnnouncement.message) return
    setSaving(true)
    
    const { data } = await supabase
      .from('announcements')
      .insert({
        title: newAnnouncement.title || null,
        message: newAnnouncement.message,
        type: newAnnouncement.type,
        is_active: true
      })
      .select()
      .single()
    
    if (data) {
      setAnnouncements(prev => [data, ...prev])
      setNewAnnouncement({ title: '', message: '', type: 'general' })
    }
    setSaving(false)
  }

  async function toggleAnnouncement(id: string, isActive: boolean) {
    await supabase
      .from('announcements')
      .update({ is_active: !isActive })
      .eq('id', id)
    
    setAnnouncements(prev => prev.map(a => a.id === id ? { ...a, is_active: !isActive } : a))
  }

  async function deleteAnnouncement(id: string) {
    await supabase.from('announcements').delete().eq('id', id)
    setAnnouncements(prev => prev.filter(a => a.id !== id))
  }

  const getSetting = (key: string) => settings.find(s => s.key === key)?.value || ''

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <RefreshCw className="w-8 h-8 text-yellow-500 animate-spin" />
      </div>
    )
  }

  return (
    <div className="space-y-8">
      {/* General Settings */}
      <GlowCard>
        <div className="p-6">
          <div className="flex items-center gap-3 mb-6">
            <Settings className="w-6 h-6 text-yellow-500" />
            <h2 className="text-xl font-bold text-white">Configuracoes Gerais</h2>
          </div>

          <div className="grid gap-6">
            {/* Admin Password */}
            <div className="space-y-2">
              <label className="flex items-center gap-2 text-sm text-gray-400">
                <Key className="w-4 h-4" />
                Senha Admin
              </label>
              <div className="flex gap-3">
                <Input
                  type="password"
                  value={getSetting('admin_password')}
                  onChange={(e) => setSettings(prev => prev.map(s => 
                    s.key === 'admin_password' ? { ...s, value: e.target.value } : s
                  ))}
                  className="bg-black/50 border-white/10 text-white"
                />
                <Button
                  onClick={() => updateSetting('admin_password', getSetting('admin_password'))}
                  disabled={saving}
                  className="bg-yellow-500 hover:bg-yellow-600 text-black"
                >
                  <Save className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* Group Link */}
            <div className="space-y-2">
              <label className="flex items-center gap-2 text-sm text-gray-400">
                <Link className="w-4 h-4" />
                Link do Grupo
              </label>
              <div className="flex gap-3">
                <Input
                  type="url"
                  value={getSetting('group_link')}
                  onChange={(e) => setSettings(prev => prev.map(s => 
                    s.key === 'group_link' ? { ...s, value: e.target.value } : s
                  ))}
                  placeholder="https://chat.whatsapp.com/..."
                  className="bg-black/50 border-white/10 text-white"
                />
                <Button
                  onClick={() => updateSetting('group_link', getSetting('group_link'))}
                  disabled={saving}
                  className="bg-yellow-500 hover:bg-yellow-600 text-black"
                >
                  <Save className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* Group Link Text */}
            <div className="space-y-2">
              <label className="flex items-center gap-2 text-sm text-gray-400">
                <Link className="w-4 h-4" />
                Texto do Link do Grupo
              </label>
              <div className="flex gap-3">
                <Input
                  type="text"
                  value={getSetting('group_link_text')}
                  onChange={(e) => setSettings(prev => prev.map(s => 
                    s.key === 'group_link_text' ? { ...s, value: e.target.value } : s
                  ))}
                  placeholder="Entre no grupo oficial da LDA"
                  className="bg-black/50 border-white/10 text-white"
                />
                <Button
                  onClick={() => updateSetting('group_link_text', getSetting('group_link_text'))}
                  disabled={saving}
                  className="bg-yellow-500 hover:bg-yellow-600 text-black"
                >
                  <Save className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* Tolerance */}
            <div className="space-y-2">
              <label className="flex items-center gap-2 text-sm text-gray-400">
                <Clock className="w-4 h-4" />
                Tolerancia de Atraso (minutos)
              </label>
              <div className="flex gap-3">
                <Input
                  type="number"
                  value={getSetting('tolerance_minutes')}
                  onChange={(e) => setSettings(prev => prev.map(s => 
                    s.key === 'tolerance_minutes' ? { ...s, value: e.target.value } : s
                  ))}
                  className="bg-black/50 border-white/10 text-white w-32"
                />
                <Button
                  onClick={() => updateSetting('tolerance_minutes', getSetting('tolerance_minutes'))}
                  disabled={saving}
                  className="bg-yellow-500 hover:bg-yellow-600 text-black"
                >
                  <Save className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </GlowCard>

      {/* Announcements */}
      <GlowCard>
        <div className="p-6">
          <div className="flex items-center gap-3 mb-6">
            <Bell className="w-6 h-6 text-yellow-500" />
            <h2 className="text-xl font-bold text-white">Avisos e Anuncios</h2>
          </div>

          {/* Add New Announcement */}
          <div className="bg-black/30 rounded-lg p-4 mb-6 border border-white/5">
            <h3 className="text-sm font-semibold text-gray-300 mb-4">Novo Aviso</h3>
            <div className="grid gap-4">
              <Input
                placeholder="Titulo (opcional)"
                value={newAnnouncement.title}
                onChange={(e) => setNewAnnouncement(prev => ({ ...prev, title: e.target.value }))}
                className="bg-black/50 border-white/10 text-white"
              />
              <Input
                placeholder="Mensagem do aviso"
                value={newAnnouncement.message}
                onChange={(e) => setNewAnnouncement(prev => ({ ...prev, message: e.target.value }))}
                className="bg-black/50 border-white/10 text-white"
              />
              <div className="flex gap-3">
                <select
                  value={newAnnouncement.type}
                  onChange={(e) => setNewAnnouncement(prev => ({ ...prev, type: e.target.value as any }))}
                  className="flex-1 bg-black/50 border border-white/10 text-white rounded-md px-3 py-2"
                >
                  <option value="general">Geral</option>
                  <option value="lobby">Lobby</option>
                  <option value="matchmaking">Matchmaking</option>
                </select>
                <Button
                  onClick={addAnnouncement}
                  disabled={saving || !newAnnouncement.message}
                  className="bg-yellow-500 hover:bg-yellow-600 text-black"
                >
                  Adicionar Aviso
                </Button>
              </div>
            </div>
          </div>

          {/* Announcements List */}
          <div className="space-y-3">
            {announcements.map((announcement) => (
              <motion.div
                key={announcement.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`p-4 rounded-lg border ${
                  announcement.is_active 
                    ? 'bg-yellow-500/10 border-yellow-500/30' 
                    : 'bg-black/30 border-white/5'
                }`}
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    {announcement.title && (
                      <h4 className="font-semibold text-white mb-1">{announcement.title}</h4>
                    )}
                    <p className="text-gray-300 text-sm">{announcement.message}</p>
                    <span className={`inline-block mt-2 text-xs px-2 py-1 rounded ${
                      announcement.type === 'lobby' ? 'bg-blue-500/20 text-blue-400' :
                      announcement.type === 'matchmaking' ? 'bg-purple-500/20 text-purple-400' :
                      'bg-gray-500/20 text-gray-400'
                    }`}>
                      {announcement.type}
                    </span>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => toggleAnnouncement(announcement.id, announcement.is_active)}
                      className={announcement.is_active ? 'border-green-500 text-green-500' : 'border-gray-500 text-gray-500'}
                    >
                      {announcement.is_active ? 'Ativo' : 'Inativo'}
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => deleteAnnouncement(announcement.id)}
                      className="border-red-500 text-red-500 hover:bg-red-500/10"
                    >
                      Excluir
                    </Button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </GlowCard>
    </div>
  )
}
