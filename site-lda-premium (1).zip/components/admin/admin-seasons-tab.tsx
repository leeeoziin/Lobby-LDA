"use client"

import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { createClient } from '@/lib/supabase/client'
import { Calendar, Plus, Pencil, Trash2, Check, X, RefreshCw, Star, RotateCcw } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { GlowCard } from '@/components/ui/glow-card'

interface Season {
  id: string
  name: string
  start_date: string | null
  end_date: string | null
  is_active: boolean
  created_at: string
}

export function AdminSeasonsTab() {
  const [seasons, setSeasons] = useState<Season[]>([])
  const [loading, setLoading] = useState(true)
  const [newSeason, setNewSeason] = useState({ name: '', start_date: '', end_date: '' })
  const [editingSeason, setEditingSeason] = useState<string | null>(null)
  const [editData, setEditData] = useState({ name: '', start_date: '', end_date: '' })

  const supabase = createClient()

  useEffect(() => {
    fetchSeasons()
  }, [])

  async function fetchSeasons() {
    setLoading(true)
    const { data } = await supabase
      .from('seasons')
      .select('*')
      .order('created_at', { ascending: false })
    
    if (data) setSeasons(data)
    setLoading(false)
  }

  async function addSeason() {
    if (!newSeason.name.trim()) return
    
    const { data } = await supabase
      .from('seasons')
      .insert({
        name: newSeason.name.trim(),
        start_date: newSeason.start_date || null,
        end_date: newSeason.end_date || null,
        is_active: false
      })
      .select()
      .single()
    
    if (data) {
      setSeasons(prev => [data, ...prev])
      setNewSeason({ name: '', start_date: '', end_date: '' })
    }
  }

  async function updateSeason(id: string) {
    if (!editData.name.trim()) return
    
    await supabase
      .from('seasons')
      .update({
        name: editData.name.trim(),
        start_date: editData.start_date || null,
        end_date: editData.end_date || null
      })
      .eq('id', id)
    
    setSeasons(prev => prev.map(s => s.id === id ? { 
      ...s, 
      name: editData.name.trim(),
      start_date: editData.start_date || null,
      end_date: editData.end_date || null
    } : s))
    setEditingSeason(null)
  }

  async function setActiveSeason(id: string) {
    // First deactivate all seasons
    await supabase.from('seasons').update({ is_active: false }).neq('id', '')
    
    // Then activate the selected one
    await supabase.from('seasons').update({ is_active: true }).eq('id', id)
    
    setSeasons(prev => prev.map(s => ({ ...s, is_active: s.id === id })))
  }

  async function deleteSeason(id: string) {
    if (!confirm('Tem certeza que deseja excluir esta temporada? Isso pode afetar as estatisticas dos jogadores.')) return
    
    await supabase.from('seasons').delete().eq('id', id)
    setSeasons(prev => prev.filter(s => s.id !== id))
  }

  async function resetSeasonStats(seasonId: string) {
    if (!confirm('Tem certeza que deseja resetar todas as estatisticas desta temporada? Esta acao nao pode ser desfeita.')) return
    
    await supabase
      .from('player_season_stats')
      .delete()
      .eq('season_id', seasonId)
    
    alert('Estatisticas da temporada resetadas com sucesso!')
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <RefreshCw className="w-8 h-8 text-yellow-500 animate-spin" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Add New Season */}
      <GlowCard>
        <div className="p-6">
          <div className="flex items-center gap-3 mb-4">
            <Plus className="w-5 h-5 text-yellow-500" />
            <h2 className="text-lg font-bold text-white">Criar Nova Temporada</h2>
          </div>
          <div className="grid gap-4">
            <Input
              placeholder="Nome da temporada"
              value={newSeason.name}
              onChange={(e) => setNewSeason(prev => ({ ...prev, name: e.target.value }))}
              className="bg-black/50 border-white/10 text-white"
            />
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-xs text-gray-400 mb-1 block">Data Inicio</label>
                <Input
                  type="date"
                  value={newSeason.start_date}
                  onChange={(e) => setNewSeason(prev => ({ ...prev, start_date: e.target.value }))}
                  className="bg-black/50 border-white/10 text-white"
                />
              </div>
              <div>
                <label className="text-xs text-gray-400 mb-1 block">Data Fim</label>
                <Input
                  type="date"
                  value={newSeason.end_date}
                  onChange={(e) => setNewSeason(prev => ({ ...prev, end_date: e.target.value }))}
                  className="bg-black/50 border-white/10 text-white"
                />
              </div>
            </div>
            <Button
              onClick={addSeason}
              disabled={!newSeason.name.trim()}
              className="bg-yellow-500 hover:bg-yellow-600 text-black"
            >
              <Plus className="w-4 h-4 mr-2" />
              Criar Temporada
            </Button>
          </div>
        </div>
      </GlowCard>

      {/* Seasons List */}
      <GlowCard>
        <div className="p-6">
          <div className="flex items-center gap-3 mb-6">
            <Calendar className="w-6 h-6 text-yellow-500" />
            <h2 className="text-xl font-bold text-white">Temporadas ({seasons.length})</h2>
          </div>

          <div className="space-y-4">
            <AnimatePresence>
              {seasons.map((season) => (
                <motion.div
                  key={season.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className={`p-4 rounded-lg border ${
                    season.is_active 
                      ? 'bg-yellow-500/10 border-yellow-500/30' 
                      : 'bg-black/40 border-white/10'
                  }`}
                >
                  {editingSeason === season.id ? (
                    <div className="space-y-4">
                      <Input
                        value={editData.name}
                        onChange={(e) => setEditData(prev => ({ ...prev, name: e.target.value }))}
                        className="bg-black/50 border-white/10 text-white"
                        autoFocus
                      />
                      <div className="grid grid-cols-2 gap-4">
                        <Input
                          type="date"
                          value={editData.start_date}
                          onChange={(e) => setEditData(prev => ({ ...prev, start_date: e.target.value }))}
                          className="bg-black/50 border-white/10 text-white"
                        />
                        <Input
                          type="date"
                          value={editData.end_date}
                          onChange={(e) => setEditData(prev => ({ ...prev, end_date: e.target.value }))}
                          className="bg-black/50 border-white/10 text-white"
                        />
                      </div>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          onClick={() => updateSeason(season.id)}
                          className="bg-green-500 hover:bg-green-600 text-white"
                        >
                          <Check className="w-4 h-4 mr-1" />
                          Salvar
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => setEditingSeason(null)}
                          className="border-white/20"
                        >
                          <X className="w-4 h-4 mr-1" />
                          Cancelar
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="flex items-center gap-3">
                          <h3 className="text-lg font-semibold text-white">{season.name}</h3>
                          {season.is_active && (
                            <span className="flex items-center gap-1 text-xs px-2 py-1 rounded bg-yellow-500/20 text-yellow-400">
                              <Star className="w-3 h-3" />
                              Ativa
                            </span>
                          )}
                        </div>
                        <div className="text-sm text-gray-400 mt-1">
                          {season.start_date && `Inicio: ${new Date(season.start_date).toLocaleDateString('pt-BR')}`}
                          {season.start_date && season.end_date && ' - '}
                          {season.end_date && `Fim: ${new Date(season.end_date).toLocaleDateString('pt-BR')}`}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {!season.is_active && (
                          <Button
                            size="sm"
                            onClick={() => setActiveSeason(season.id)}
                            className="bg-yellow-500 hover:bg-yellow-600 text-black"
                          >
                            <Star className="w-4 h-4 mr-1" />
                            Ativar
                          </Button>
                        )}
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => resetSeasonStats(season.id)}
                          className="text-orange-400 hover:text-orange-300"
                        >
                          <RotateCcw className="w-4 h-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => {
                            setEditingSeason(season.id)
                            setEditData({
                              name: season.name,
                              start_date: season.start_date || '',
                              end_date: season.end_date || ''
                            })
                          }}
                          className="text-blue-400 hover:text-blue-300"
                        >
                          <Pencil className="w-4 h-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => deleteSeason(season.id)}
                          className="text-red-400 hover:text-red-300"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  )}
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>
      </GlowCard>
    </div>
  )
}
