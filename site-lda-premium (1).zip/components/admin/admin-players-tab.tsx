'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  Plus, 
  Edit, 
  Trash2, 
  Search,
  Save,
  X,
  ChevronUp,
  ChevronDown,
  Monitor,
  Gamepad2
} from 'lucide-react'
import { usePlayers } from '@/hooks/use-supabase'
import { createClient } from '@/lib/supabase/client'
import { GlowCard } from '@/components/ui/glow-card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { cn } from '@/lib/utils'
import type { Player } from '@/lib/types/database'

const supabase = createClient()

interface StatInputProps {
  label: string
  value: number
  onChange: (value: number) => void
  color?: string
}

function StatInput({ label, value, onChange, color = 'text-foreground' }: StatInputProps) {
  return (
    <div className="flex items-center gap-2">
      <span className="text-xs text-muted-foreground w-20">{label}</span>
      <Button
        type="button"
        variant="outline"
        size="sm"
        className="w-8 h-8 p-0"
        onClick={() => onChange(Math.max(0, value - 1))}
      >
        <ChevronDown className="w-4 h-4" />
      </Button>
      <Input
        type="number"
        value={value}
        onChange={(e) => onChange(parseInt(e.target.value) || 0)}
        className={cn("w-20 text-center h-8", color)}
      />
      <Button
        type="button"
        variant="outline"
        size="sm"
        className="w-8 h-8 p-0"
        onClick={() => onChange(value + 1)}
      >
        <ChevronUp className="w-4 h-4" />
      </Button>
    </div>
  )
}

export function AdminPlayersTab() {
  const { players, loading, refetch } = usePlayers()
  const [search, setSearch] = useState('')
  const [editingPlayer, setEditingPlayer] = useState<Player | null>(null)
  const [showAddForm, setShowAddForm] = useState(false)
  const [newPlayer, setNewPlayer] = useState({
    nickname: '',
    platform: 'PC' as 'PC' | 'Xbox' | 'PSN',
    elo: 1000,
    kills: 0,
    deaths: 0,
    assists: 0,
    matches_played: 0,
    wins: 0,
    wins_ot: 0,
    losses_ot: 0,
    losses: 0,
    points: 0,
    mvp_count: 0,
    current_streak: 0,
    kost: 0
  })

  const filteredPlayers = players.filter(p => 
    p.nickname.toLowerCase().includes(search.toLowerCase())
  )

  const handleSavePlayer = async (player: Player) => {
    const { error } = await supabase
      .from('players')
      .update({
        nickname: player.nickname,
        platform: player.platform,
        elo: player.elo,
        kills: player.kills,
        deaths: player.deaths,
        assists: player.assists,
        matches_played: player.matches_played,
        wins: player.wins,
        wins_ot: player.wins_ot,
        losses_ot: player.losses_ot,
        losses: player.losses,
        points: player.points,
        mvp_count: player.mvp_count,
        current_streak: player.current_streak,
        kost: player.kost,
        updated_at: new Date().toISOString()
      })
      .eq('id', player.id)

    if (!error) {
      setEditingPlayer(null)
      refetch()
    }
  }

  const handleAddPlayer = async () => {
    if (!newPlayer.nickname.trim()) return

    const { error } = await supabase
      .from('players')
      .insert(newPlayer)

    if (!error) {
      setShowAddForm(false)
      setNewPlayer({
        nickname: '',
        platform: 'PC',
        elo: 1000,
        kills: 0,
        deaths: 0,
        assists: 0,
        matches_played: 0,
        wins: 0,
        wins_ot: 0,
        losses_ot: 0,
        losses: 0,
        points: 0,
        mvp_count: 0,
        current_streak: 0,
        kost: 0
      })
      refetch()
    }
  }

  const handleDeletePlayer = async (playerId: string) => {
    if (!confirm('Tem certeza que deseja excluir este jogador?')) return

    const { error } = await supabase
      .from('players')
      .delete()
      .eq('id', playerId)

    if (!error) {
      refetch()
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row gap-4 justify-between">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Buscar jogador..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10"
          />
        </div>
        <Button
          onClick={() => setShowAddForm(true)}
          className="bg-primary text-primary-foreground glow-yellow-sm"
        >
          <Plus className="w-4 h-4 mr-2" />
          Adicionar Jogador
        </Button>
      </div>

      {/* Add Player Form */}
      <AnimatePresence>
        {showAddForm && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
          >
            <GlowCard>
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold text-lg">Novo Jogador</h3>
                <Button variant="ghost" size="sm" onClick={() => setShowAddForm(false)}>
                  <X className="w-4 h-4" />
                </Button>
              </div>

              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <div>
                  <label className="text-sm text-muted-foreground mb-1 block">Nickname</label>
                  <Input
                    value={newPlayer.nickname}
                    onChange={(e) => setNewPlayer({ ...newPlayer, nickname: e.target.value })}
                    placeholder="Nome do jogador"
                  />
                </div>
                <div>
                  <label className="text-sm text-muted-foreground mb-1 block">Plataforma</label>
                  <div className="flex gap-2">
                    {['PC', 'Xbox', 'PSN'].map(p => (
                      <Button
                        key={p}
                        type="button"
                        variant={newPlayer.platform === p ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => setNewPlayer({ ...newPlayer, platform: p as 'PC' | 'Xbox' | 'PSN' })}
                        className={cn(newPlayer.platform === p && "bg-primary text-primary-foreground")}
                      >
                        {p}
                      </Button>
                    ))}
                  </div>
                </div>
                <StatInput 
                  label="ELO" 
                  value={newPlayer.elo} 
                  onChange={(v) => setNewPlayer({ ...newPlayer, elo: v })}
                />
                <StatInput 
                  label="Kills" 
                  value={newPlayer.kills} 
                  onChange={(v) => setNewPlayer({ ...newPlayer, kills: v })}
                  color="text-green-500"
                />
                <StatInput 
                  label="Deaths" 
                  value={newPlayer.deaths} 
                  onChange={(v) => setNewPlayer({ ...newPlayer, deaths: v })}
                  color="text-red-500"
                />
                <StatInput 
                  label="Assists" 
                  value={newPlayer.assists} 
                  onChange={(v) => setNewPlayer({ ...newPlayer, assists: v })}
                  color="text-blue-500"
                />
              </div>

              <div className="flex justify-end gap-2 mt-4">
                <Button variant="outline" onClick={() => setShowAddForm(false)}>
                  Cancelar
                </Button>
                <Button 
                  onClick={handleAddPlayer}
                  className="bg-primary text-primary-foreground"
                >
                  <Save className="w-4 h-4 mr-2" />
                  Salvar
                </Button>
              </div>
            </GlowCard>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Players List */}
      <div className="space-y-3">
        {filteredPlayers.map((player) => (
          <motion.div
            key={player.id}
            layout
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            {editingPlayer?.id === player.id ? (
              <GlowCard className="border border-primary/50">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-bold">Editando: {player.nickname}</h3>
                  <Button variant="ghost" size="sm" onClick={() => setEditingPlayer(null)}>
                    <X className="w-4 h-4" />
                  </Button>
                </div>

                <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div>
                    <label className="text-sm text-muted-foreground mb-1 block">Nickname</label>
                    <Input
                      value={editingPlayer.nickname}
                      onChange={(e) => setEditingPlayer({ ...editingPlayer, nickname: e.target.value })}
                    />
                  </div>
                  <div>
                    <label className="text-sm text-muted-foreground mb-1 block">Plataforma</label>
                    <div className="flex gap-2">
                      {['PC', 'Xbox', 'PSN'].map(p => (
                        <Button
                          key={p}
                          type="button"
                          variant={editingPlayer.platform === p ? 'default' : 'outline'}
                          size="sm"
                          onClick={() => setEditingPlayer({ ...editingPlayer, platform: p as 'PC' | 'Xbox' | 'PSN' })}
                          className={cn(editingPlayer.platform === p && "bg-primary text-primary-foreground")}
                        >
                          {p}
                        </Button>
                      ))}
                    </div>
                  </div>
                  <StatInput 
                    label="ELO" 
                    value={editingPlayer.elo} 
                    onChange={(v) => setEditingPlayer({ ...editingPlayer, elo: v })}
                  />
                  <StatInput 
                    label="Pontos" 
                    value={editingPlayer.points} 
                    onChange={(v) => setEditingPlayer({ ...editingPlayer, points: v })}
                  />
                  <StatInput 
                    label="Kills" 
                    value={editingPlayer.kills} 
                    onChange={(v) => setEditingPlayer({ ...editingPlayer, kills: v })}
                    color="text-green-500"
                  />
                  <StatInput 
                    label="Deaths" 
                    value={editingPlayer.deaths} 
                    onChange={(v) => setEditingPlayer({ ...editingPlayer, deaths: v })}
                    color="text-red-500"
                  />
                  <StatInput 
                    label="Assists" 
                    value={editingPlayer.assists} 
                    onChange={(v) => setEditingPlayer({ ...editingPlayer, assists: v })}
                    color="text-blue-500"
                  />
                  <StatInput 
                    label="Partidas" 
                    value={editingPlayer.matches_played} 
                    onChange={(v) => setEditingPlayer({ ...editingPlayer, matches_played: v })}
                  />
                  <StatInput 
                    label="Vitorias" 
                    value={editingPlayer.wins} 
                    onChange={(v) => setEditingPlayer({ ...editingPlayer, wins: v })}
                    color="text-green-500"
                  />
                  <StatInput 
                    label="V. OT" 
                    value={editingPlayer.wins_ot} 
                    onChange={(v) => setEditingPlayer({ ...editingPlayer, wins_ot: v })}
                    color="text-green-400"
                  />
                  <StatInput 
                    label="D. OT" 
                    value={editingPlayer.losses_ot} 
                    onChange={(v) => setEditingPlayer({ ...editingPlayer, losses_ot: v })}
                    color="text-orange-400"
                  />
                  <StatInput 
                    label="Derrotas" 
                    value={editingPlayer.losses} 
                    onChange={(v) => setEditingPlayer({ ...editingPlayer, losses: v })}
                    color="text-red-500"
                  />
                  <StatInput 
                    label="MVPs" 
                    value={editingPlayer.mvp_count} 
                    onChange={(v) => setEditingPlayer({ ...editingPlayer, mvp_count: v })}
                    color="text-primary"
                  />
                  <StatInput 
                    label="Streak" 
                    value={editingPlayer.current_streak} 
                    onChange={(v) => setEditingPlayer({ ...editingPlayer, current_streak: v })}
                  />
                  <StatInput 
                    label="KOST" 
                    value={editingPlayer.kost} 
                    onChange={(v) => setEditingPlayer({ ...editingPlayer, kost: v })}
                  />
                </div>

                <div className="flex justify-end gap-2 mt-4">
                  <Button variant="outline" onClick={() => setEditingPlayer(null)}>
                    Cancelar
                  </Button>
                  <Button 
                    onClick={() => handleSavePlayer(editingPlayer)}
                    className="bg-primary text-primary-foreground"
                  >
                    <Save className="w-4 h-4 mr-2" />
                    Salvar
                  </Button>
                </div>
              </GlowCard>
            ) : (
              <GlowCard className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                  <span className="font-bold text-primary">
                    {player.nickname.charAt(0).toUpperCase()}
                  </span>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium truncate">{player.nickname}</p>
                  <p className="text-sm text-muted-foreground">
                    {player.platform} • ELO {player.elo} • {player.points} pts
                  </p>
                </div>
                <div className="hidden sm:flex items-center gap-4 text-sm">
                  <span className="text-green-500">{player.kills}K</span>
                  <span className="text-red-500">{player.deaths}D</span>
                  <span className="text-blue-500">{player.assists}A</span>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setEditingPlayer(player)}
                  >
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleDeletePlayer(player.id)}
                    className="text-destructive hover:text-destructive"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </GlowCard>
            )}
          </motion.div>
        ))}
      </div>
    </div>
  )
}
