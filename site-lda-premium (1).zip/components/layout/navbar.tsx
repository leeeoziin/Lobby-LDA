'use client'

import { useState } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  Home, 
  Trophy, 
  Users, 
  Swords, 
  Shield, 
  Menu, 
  X,
  LogIn,
  LogOut
} from 'lucide-react'
import { useAdmin } from '@/components/providers/admin-provider'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import { AdminLoginModal } from '@/components/modals/admin-login-modal'

const navItems = [
  { href: '/', label: 'Home', icon: Home },
  { href: '/ranking', label: 'Ranking', icon: Trophy },
  { href: '/lobby', label: 'Lobby', icon: Users },
  { href: '/partidas', label: 'Partidas', icon: Swords },
]

export function Navbar() {
  const pathname = usePathname()
  const { isAdmin, logout } = useAdmin()
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false)

  return (
    <>
      <motion.nav 
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        className="fixed top-0 left-0 right-0 z-50 glass-dark"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link href="/" className="flex items-center gap-2">
              <div className="relative">
                <div className="w-10 h-10 rounded-lg bg-primary flex items-center justify-center glow-yellow-sm">
                  <span className="font-bold text-primary-foreground text-lg">LDA</span>
                </div>
              </div>
              <span className="hidden sm:block font-bold text-xl text-foreground">
                Lobby <span className="text-primary">Premium</span>
              </span>
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center gap-1">
              {navItems.map((item) => {
                const isActive = pathname === item.href
                return (
                  <Link key={item.href} href={item.href}>
                    <motion.div
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className={cn(
                        "flex items-center gap-2 px-4 py-2 rounded-lg transition-all duration-200",
                        isActive 
                          ? "bg-primary text-primary-foreground glow-yellow-sm" 
                          : "text-muted-foreground hover:text-foreground hover:bg-secondary"
                      )}
                    >
                      <item.icon className="w-4 h-4" />
                      <span className="font-medium">{item.label}</span>
                    </motion.div>
                  </Link>
                )
              })}
              
              {isAdmin && (
                <Link href="/admin">
                  <motion.div
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className={cn(
                      "flex items-center gap-2 px-4 py-2 rounded-lg transition-all duration-200",
                      pathname === '/admin'
                        ? "bg-primary text-primary-foreground glow-yellow-sm" 
                        : "text-muted-foreground hover:text-foreground hover:bg-secondary"
                    )}
                  >
                    <Shield className="w-4 h-4" />
                    <span className="font-medium">Admin</span>
                  </motion.div>
                </Link>
              )}
            </div>

            {/* Auth Button */}
            <div className="hidden md:flex items-center gap-2">
              {isAdmin ? (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={logout}
                  className="border-primary/50 text-primary hover:bg-primary/10"
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  Sair
                </Button>
              ) : (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setIsLoginModalOpen(true)}
                  className="border-primary/50 text-primary hover:bg-primary/10"
                >
                  <LogIn className="w-4 h-4 mr-2" />
                  Admin
                </Button>
              )}
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="md:hidden p-2 rounded-lg text-foreground hover:bg-secondary"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden glass-dark border-t border-border"
            >
              <div className="px-4 py-4 space-y-2">
                {navItems.map((item) => {
                  const isActive = pathname === item.href
                  return (
                    <Link 
                      key={item.href} 
                      href={item.href}
                      onClick={() => setIsMobileMenuOpen(false)}
                    >
                      <div
                        className={cn(
                          "flex items-center gap-3 px-4 py-3 rounded-lg transition-all",
                          isActive 
                            ? "bg-primary text-primary-foreground" 
                            : "text-muted-foreground hover:text-foreground hover:bg-secondary"
                        )}
                      >
                        <item.icon className="w-5 h-5" />
                        <span className="font-medium">{item.label}</span>
                      </div>
                    </Link>
                  )
                })}
                
                {isAdmin && (
                  <Link href="/admin" onClick={() => setIsMobileMenuOpen(false)}>
                    <div
                      className={cn(
                        "flex items-center gap-3 px-4 py-3 rounded-lg transition-all",
                        pathname === '/admin'
                          ? "bg-primary text-primary-foreground" 
                          : "text-muted-foreground hover:text-foreground hover:bg-secondary"
                      )}
                    >
                      <Shield className="w-5 h-5" />
                      <span className="font-medium">Admin</span>
                    </div>
                  </Link>
                )}

                <div className="pt-2 border-t border-border">
                  {isAdmin ? (
                    <button
                      onClick={() => {
                        logout()
                        setIsMobileMenuOpen(false)
                      }}
                      className="flex items-center gap-3 px-4 py-3 rounded-lg text-destructive hover:bg-destructive/10 w-full"
                    >
                      <LogOut className="w-5 h-5" />
                      <span className="font-medium">Sair</span>
                    </button>
                  ) : (
                    <button
                      onClick={() => {
                        setIsLoginModalOpen(true)
                        setIsMobileMenuOpen(false)
                      }}
                      className="flex items-center gap-3 px-4 py-3 rounded-lg text-primary hover:bg-primary/10 w-full"
                    >
                      <LogIn className="w-5 h-5" />
                      <span className="font-medium">Login Admin</span>
                    </button>
                  )}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.nav>

      <AdminLoginModal 
        isOpen={isLoginModalOpen} 
        onClose={() => setIsLoginModalOpen(false)} 
      />
    </>
  )
}
