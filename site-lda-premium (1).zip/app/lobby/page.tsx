'use client'

import { useState, useEffect, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  Users, 
  UserPlus, 
  UserMinus,
  AlertCircle,
  ExternalLink,
  Clock,
  Volume2,
  Monitor,
  Gamepad2,
  CheckCircle,
  XCircle
} from 'lucide-react'
import { Navbar } from '@/components/layout/navbar'
import { ParticleBackground } from '@/components/effects/particle-background'
import { GlowCard } from '@/components/ui/glow-card'
import { useLobby, useSettings, useAnnouncements, useDrawResults } from '@/hooks/use-supabase'
import { useAdmin } from '@/components/providers/admin-provider'
import { createClient } from '@/lib/supabase/client'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { CardSkeleton } from '@/components/ui/loading-skeleton'
import { cn } from '@/lib/utils'
import { DrawAnimation } from '@/components/lobby/draw-animation'

const supabase = createClient()

const platforms = [
  { value: 'PC', label: 'PC', icon: Monitor },
  { value: 'Xbox', label: 'Xbox', icon: Gamepad2 },
  { value: 'PSN', label: 'PSN', icon: Gamepad2 },
]

export default function LobbyPage() {
  const { lobby, players, loading, refetch } = useLobby()
  const { settings } = useSettings()
  const { announcements } = useAnnouncements('lobby')
  const { drawResults } = useDrawResults()
  const { isAdmin } = useAdmin()
  
  const [nickname, setNickname] = useState('')
  const [platform, setPlatform] = useState<'PC' | 'Xbox' | 'PSN'>('PC')
  const [isJoining, setIsJoining] = useState(false)
  const [error, setError] = useState('')
  const [showDrawAnimation, setShowDrawAnimation] = useState(false)
  const [currentDrawResult, setCurrentDrawResult] = useState<typeof drawResults[0] | null>(null)
  const audioRef = useRef<HTMLAudioElement | null>(null)

  const titulares = players.filter(p => !p.is_reserve)
  const reservas = players.filter(p => p.is_reserve)
  const isFull = titulares.length >= (lobby?.max_players || 10)
  const myPlayer = players.find(p => p.nickname.toLowerCase() === nickname.toLowerCase())

  // Audio notification when lobby is full
  useEffect(() => {
    if (isFull && lobby?.is_open) {
      try {
        audioRef.current = new Audio('/notification.mp3')
        audioRef.current.play().catch(() => {})
      } catch {}
    }
  }, [isFull, lobby?.is_open])

  // Check for new draw results
  useEffect(() => {
    if (drawResults.length > 0 && lobby) {
      const latestDraw = drawResults.find(d => d.lobby_id === lobby.id)
      if (latestDraw && !currentDrawResult) {
        setCurrentDrawResult(latestDraw)
        setShowDrawAnimation(true)
      }
    }
  }, [drawResults, lobby, currentDrawResult])

  const handleJoin = async () => {
    if (!nickname.trim()) {
      setError('Digite seu nickname')
      return
    }
    if (!lobby) return

    setIsJoining(true)
    setError('')

    try {
      // Check if player exists, if not create
      let { data: existingPlayer } = await supabase
        .from('players')
        .select('id')
        .eq('nickname', nickname.trim())
        .single()

      if (!existingPlayer) {
        const { data: newPlayer, error: createError } = await supabase
          .from('players')
          .insert({
            nickname: nickname.trim(),
            platform,
          })
          .select()
          .single()

        if (createError) throw createError
        existingPlayer = newPlayer
      }

      // Check if already in lobby
      const { data: existingLobbyPlayer } = await supabase
        .from('lobby_players')
        .select('id')
        .eq('lobby_id', lobby.id)
        .eq('nickname', nickname.trim())
        .single()

      if (existingLobbyPlayer) {
        setError('Voce ja esta no lobby')
        setIsJoining(false)
        return
      }

      // Determine if reserve
      const isReserve = titulares.length >= (lobby.max_players || 10)

      if (isReserve && reservas.length >= (lobby.max_reserves || 3)) {
        setError('Lobby e reservas estao cheios')
        setIsJoining(false)
        return
      }

      // Add to lobby
      const { error: joinError } = await supabase
        .from('lobby_players')
        .insert({
          lobby_id: lobby.id,
          player_id: existingPlayer?.id,
          nickname: nickname.trim(),
          platform,
          is_reserve: isReserve,
        })

      if (joinError) throw joinError

      localStorage.setItem('lda_lobby_nickname', nickname.trim())
      refetch()
    } catch (err: any) {
      setError(err.message || 'Erro ao entrar no lobby')
    }

    setIsJoining(false)
  }

  const handleLeave = async () => {
    if (!myPlayer || !lobby) return

    try {
      await supabase
        .from('lobby_players')
        .delete()
        .eq('lobby_id', lobby.id)
        .eq('nickname', nickname.trim())

      // If a reserve exists, promote them to titular
      if (reservas.length > 0) {
        const firstReserve = reservas[0]
        await supabase
          .from('lobby_players')
          .update({ is_reserve: false })
          .eq('id', firstReserve.id)
      }

      refetch()
    } catch (err) {
      console.error('Error leaving lobby:', err)
    }
  }

  // Load saved nickname
  useEffect(() => {
    const saved = localStorage.getItem('lda_lobby_nickname')
    if (saved) setNickname(saved)
  }, [])

  return (
    <div className="min-h-screen bg-background relative">
      <ParticleBackground />
      <Navbar />

      <main className="relative z-10 pt-24 px-4 pb-20">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-8"
          >
            <h1 className="text-3xl sm:text-4xl font-black mb-2">
              Lobby <span className="text-primary">5v5</span>
            </h1>
            <p className="text-muted-foreground">
              Matchmaking automatico para partidas competitivas
            </p>
          </motion.div>

          {/* Announcements */}
          {announcements.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="mb-6 space-y-2"
            >
              {announcements.map((ann) => (
                <div 
                  key={ann.id}
                  className="glass rounded-lg p-4 flex items-start gap-3 border-l-4 border-primary"
                >
                  <AlertCircle className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                  <div>
                    {ann.title && <p className="font-medium text-foreground mb-1">{ann.title}</p>}
                    <p className="text-sm text-muted-foreground">{ann.message}</p>
                  </div>
                </div>
              ))}
            </motion.div>
          )}

          {loading ? (
            <CardSkeleton />
          ) : !lobby ? (
            <GlowCard className="text-center py-12">
              <Users className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <p className="text-xl font-bold mb-2">Nenhum lobby ativo</p>
              <p className="text-muted-foreground">Aguarde a abertura do proximo lobby</p>
            </GlowCard>
          ) : (
            <>
              {/* Lobby Status */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.15 }}
              >
                <GlowCard className="mb-6">
                  <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mb-6">
                    <div className="flex items-center gap-4">
                      <div className={cn(
                        "w-4 h-4 rounded-full",
                        lobby.is_open ? "bg-green-500 animate-pulse" : "bg-red-500"
                      )} />
                      <span className="font-bold text-lg">
                        {lobby.is_open ? 'Lobby Aberto' : 'Lobby Fechado'}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Clock className="w-4 h-4" />
                      {lobby.scheduled_datetime && (
                        <span className="text-sm">
                          {new Date(lobby.scheduled_datetime).toLocaleString('pt-BR')}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Slots Counter */}
                  <div className="text-center mb-6">
                    <div className="text-6xl font-black text-primary mb-2">
                      {titulares.length}/{lobby.max_players}
                    </div>
                    <p className="text-muted-foreground">Jogadores</p>
                    {reservas.length > 0 && (
                      <p className="text-sm text-muted-foreground mt-1">
                        + {reservas.length} reserva{reservas.length > 1 ? 's' : ''}
                      </p>
                    )}
                  </div>

                  {/* Progress Bar */}
                  <div className="w-full h-3 bg-secondary rounded-full overflow-hidden mb-6">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${(titulares.length / lobby.max_players) * 100}%` }}
                      className="h-full bg-primary rounded-full"
                      transition={{ duration: 0.5 }}
                    />
                  </div>

                  {/* Join Form */}
                  {lobby.is_open && !myPlayer && (
                    <div className="space-y-4">
                      <div className="glass-dark rounded-lg p-4">
                        <p className="text-sm text-primary mb-3 flex items-center gap-2">
                          <AlertCircle className="w-4 h-4" />
                          Certifique-se de digitar seu nickname corretamente para facilitar o convite no jogo
                        </p>
                        
                        <div className="flex flex-col sm:flex-row gap-3">
                          <Input
                            type="text"
                            placeholder="Digite seu nickname..."
                            value={nickname}
                            onChange={(e) => setNickname(e.target.value)}
                            className="flex-1 bg-secondary border-border"
                          />
                          
                          <div className="flex gap-2">
                            {platforms.map(p => (
                              <Button
                                key={p.value}
                                variant={platform === p.value ? 'default' : 'outline'}
                                size="sm"
                                onClick={() => setPlatform(p.value as 'PC' | 'Xbox' | 'PSN')}
                                className={cn(
                                  "flex-1 sm:flex-none",
                                  platform === p.value && "bg-primary text-primary-foreground"
                                )}
                              >
                                <p.icon className="w-4 h-4 mr-1" />
                                {p.label}
                              </Button>
                            ))}
                          </div>
                        </div>

                        {error && (
                          <p className="text-sm text-destructive mt-2 flex items-center gap-1">
                            <XCircle className="w-4 h-4" />
                            {error}
                          </p>
                        )}
                      </div>

                      <Button
                        onClick={handleJoin}
                        disabled={isJoining || !nickname.trim() || (!lobby.is_open)}
                        className="w-full bg-primary text-primary-foreground hover:bg-primary/90 glow-yellow"
                      >
                        {isJoining ? (
                          'Entrando...'
                        ) : isFull ? (
                          <>
                            <UserPlus className="w-4 h-4 mr-2" />
                            Entrar como Reserva
                          </>
                        ) : (
                          <>
                            <UserPlus className="w-4 h-4 mr-2" />
                            Entrar no Lobby
                          </>
                        )}
                      </Button>

                      <p className="text-xs text-center text-muted-foreground">
                        Tolerancia de atraso: {settings.tolerance_minutes || 10} minutos apos entrar
                      </p>
                    </div>
                  )}

                  {/* Already in lobby */}
                  {myPlayer && (
                    <div className="space-y-4">
                      <div className="glass-dark rounded-lg p-4 flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <CheckCircle className="w-5 h-5 text-green-500" />
                          <div>
                            <p className="font-medium">Voce esta no lobby</p>
                            <p className="text-sm text-muted-foreground">
                              {myPlayer.is_reserve ? 'Reserva' : 'Titular'} • {myPlayer.platform}
                            </p>
                          </div>
                        </div>
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={handleLeave}
                        >
                          <UserMinus className="w-4 h-4 mr-2" />
                          Sair
                        </Button>
                      </div>

                      {/* Group Link */}
                      {settings.group_link && (
                        <a
                          href={settings.group_link}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="block"
                        >
                          <div className="glass rounded-lg p-4 flex items-center justify-between hover:border-primary/50 transition-colors border border-transparent">
                            <div className="flex items-center gap-3">
                              <Volume2 className="w-5 h-5 text-primary" />
                              <span className="font-medium">
                                {settings.group_link_text || 'Entre no grupo oficial da LDA'}
                              </span>
                            </div>
                            <ExternalLink className="w-4 h-4 text-muted-foreground" />
                          </div>
                        </a>
                      )}
                    </div>
                  )}
                </GlowCard>
              </motion.div>

              {/* Players List */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
              >
                <h2 className="text-xl font-bold mb-4">
                  Jogadores <span className="text-primary">Titulares</span>
                </h2>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mb-6">
                  {Array.from({ length: lobby.max_players }).map((_, i) => {
                    const player = titulares[i]
                    return (
                      <motion.div
                        key={i}
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: 0.05 * i }}
                        className={cn(
                          "glass rounded-lg p-3 text-center min-h-[80px] flex flex-col items-center justify-center",
                          player && "border border-primary/30 glow-yellow-sm"
                        )}
                      >
                        {player ? (
                          <>
                            <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center mb-2">
                              <span className="font-bold text-primary">
                                {player.nickname.charAt(0).toUpperCase()}
                              </span>
                            </div>
                            <p className="text-sm font-medium truncate w-full">{player.nickname}</p>
                            <p className="text-xs text-muted-foreground">{player.platform}</p>
                          </>
                        ) : (
                          <>
                            <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center mb-2">
                              <span className="text-muted-foreground">{i + 1}</span>
                            </div>
                            <p className="text-xs text-muted-foreground">Vago</p>
                          </>
                        )}
                      </motion.div>
                    )
                  })}
                </div>

                {/* Reserves */}
                {lobby.max_reserves > 0 && (
                  <>
                    <h2 className="text-lg font-bold mb-3">
                      Reservas <span className="text-muted-foreground">({reservas.length}/{lobby.max_reserves})</span>
                    </h2>
                    <div className="grid grid-cols-3 gap-3">
                      {Array.from({ length: lobby.max_reserves }).map((_, i) => {
                        const reserve = reservas[i]
                        return (
                          <motion.div
                            key={i}
                            initial={{ opacity: 0, scale: 0.9 }}
                            animate={{ opacity: 1, scale: 1 }}
                            transition={{ delay: 0.05 * i }}
                            className={cn(
                              "glass rounded-lg p-3 text-center",
                              reserve && "border border-orange-500/30"
                            )}
                          >
                            {reserve ? (
                              <>
                                <p className="text-sm font-medium truncate">{reserve.nickname}</p>
                                <p className="text-xs text-muted-foreground">{reserve.platform}</p>
                              </>
                            ) : (
                              <p className="text-xs text-muted-foreground">Reserva {i + 1}</p>
                            )}
                          </motion.div>
                        )
                      })}
                    </div>
                  </>
                )}
              </motion.div>

              {/* Latest Draw Result */}
              {currentDrawResult && !showDrawAnimation && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                  className="mt-8"
                >
                  <h2 className="text-xl font-bold mb-4">
                    Ultimo <span className="text-primary">Sorteio</span>
                  </h2>
                  <GlowCard>
                    <div className="text-center mb-6">
                      <p className="text-sm text-muted-foreground mb-2">Mapa Sorteado</p>
                      <p className="text-2xl font-bold text-primary">{currentDrawResult.map?.name}</p>
                    </div>

                    <div className="grid md:grid-cols-2 gap-6">
                      {/* Team A */}
                      <div className="glass-dark rounded-lg p-4">
                        <div className="flex items-center justify-between mb-4">
                          <h3 className="font-bold text-lg">TIME A</h3>
                          <span className={cn(
                            "px-3 py-1 rounded-full text-sm font-medium",
                            currentDrawResult.team_a_side === 'ATAQUE' 
                              ? "bg-red-500/20 text-red-500" 
                              : "bg-blue-500/20 text-blue-500"
                          )}>
                            {currentDrawResult.team_a_side}
                          </span>
                        </div>
                        <div className="space-y-2">
                          {currentDrawResult.team_a_players?.map((p, i) => (
                            <div key={i} className="flex items-center gap-2">
                              <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
                                <span className="text-xs font-bold text-primary">
                                  {p.nickname.charAt(0).toUpperCase()}
                                </span>
                              </div>
                              <span className="text-sm">{p.nickname}</span>
                              <span className="text-xs text-muted-foreground ml-auto">{p.platform}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Team B */}
                      <div className="glass-dark rounded-lg p-4">
                        <div className="flex items-center justify-between mb-4">
                          <h3 className="font-bold text-lg">TIME B</h3>
                          <span className={cn(
                            "px-3 py-1 rounded-full text-sm font-medium",
                            currentDrawResult.team_b_side === 'ATAQUE' 
                              ? "bg-red-500/20 text-red-500" 
                              : "bg-blue-500/20 text-blue-500"
                          )}>
                            {currentDrawResult.team_b_side}
                          </span>
                        </div>
                        <div className="space-y-2">
                          {currentDrawResult.team_b_players?.map((p, i) => (
                            <div key={i} className="flex items-center gap-2">
                              <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
                                <span className="text-xs font-bold text-primary">
                                  {p.nickname.charAt(0).toUpperCase()}
                                </span>
                              </div>
                              <span className="text-sm">{p.nickname}</span>
                              <span className="text-xs text-muted-foreground ml-auto">{p.platform}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </GlowCard>
                </motion.div>
              )}
            </>
          )}
        </div>
      </main>

      {/* Draw Animation Modal */}
      <AnimatePresence>
        {showDrawAnimation && currentDrawResult && (
          <DrawAnimation
            drawResult={currentDrawResult}
            onComplete={() => setShowDrawAnimation(false)}
          />
        )}
      </AnimatePresence>
    </div>
  )
}
