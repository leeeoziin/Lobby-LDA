'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { motion } from 'framer-motion'
import { 
  Users, 
  Swords, 
  Map as MapIcon, 
  Settings,
  Bell,
  Trophy,
  UserPlus,
  Plus,
  Calendar,
  Link as LinkIcon,
  Play,
  RefreshCw,
  Trash2,
  Edit
} from 'lucide-react'
import { Navbar } from '@/components/layout/navbar'
import { ParticleBackground } from '@/components/effects/particle-background'
import { GlowCard } from '@/components/ui/glow-card'
import { useAdmin } from '@/components/providers/admin-provider'
import { usePlayers, useMatches, useMaps, useSeasons, useSettings, useAnnouncements, useLobby } from '@/hooks/use-supabase'
import { createClient } from '@/lib/supabase/client'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { cn } from '@/lib/utils'
import { AdminPlayersTab } from '@/components/admin/admin-players-tab'
import { AdminMatchesTab } from '@/components/admin/admin-matches-tab'
import { AdminLobbyTab } from '@/components/admin/admin-lobby-tab'
import { AdminMapsTab } from '@/components/admin/admin-maps-tab'
import { AdminSettingsTab } from '@/components/admin/admin-settings-tab'
import { AdminSeasonsTab } from '@/components/admin/admin-seasons-tab'

const supabase = createClient()

const tabs = [
  { id: 'players', label: 'Jogadores', icon: Users },
  { id: 'matches', label: 'Partidas', icon: Swords },
  { id: 'lobby', label: 'Lobby', icon: Play },
  { id: 'maps', label: 'Mapas', icon: MapIcon },
  { id: 'seasons', label: 'Temporadas', icon: Trophy },
  { id: 'settings', label: 'Configuracoes', icon: Settings },
]

export default function AdminPage() {
  const router = useRouter()
  const { isAdmin } = useAdmin()
  const [activeTab, setActiveTab] = useState('players')

  useEffect(() => {
    if (!isAdmin) {
      router.push('/')
    }
  }, [isAdmin, router])

  if (!isAdmin) {
    return null
  }

  return (
    <div className="min-h-screen bg-background relative">
      <ParticleBackground />
      <Navbar />

      <main className="relative z-10 pt-24 px-4 pb-20">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
          >
            <h1 className="text-3xl sm:text-4xl font-black mb-2">
              Painel <span className="text-primary">Admin</span>
            </h1>
            <p className="text-muted-foreground">
              Gerencie jogadores, partidas, lobby e configuracoes
            </p>
          </motion.div>

          {/* Tabs */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="flex flex-wrap gap-2 mb-6"
          >
            {tabs.map(tab => (
              <Button
                key={tab.id}
                variant={activeTab === tab.id ? 'default' : 'outline'}
                onClick={() => setActiveTab(tab.id)}
                className={cn(
                  activeTab === tab.id && "bg-primary text-primary-foreground glow-yellow-sm"
                )}
              >
                <tab.icon className="w-4 h-4 mr-2" />
                {tab.label}
              </Button>
            ))}
          </motion.div>

          {/* Tab Content */}
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.2 }}
          >
            {activeTab === 'players' && <AdminPlayersTab />}
            {activeTab === 'matches' && <AdminMatchesTab />}
            {activeTab === 'lobby' && <AdminLobbyTab />}
            {activeTab === 'maps' && <AdminMapsTab />}
            {activeTab === 'seasons' && <AdminSeasonsTab />}
            {activeTab === 'settings' && <AdminSettingsTab />}
          </motion.div>
        </div>
      </main>
    </div>
  )
}
