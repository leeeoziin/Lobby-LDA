'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { 
  Swords, 
  Trophy, 
  Calendar,
  MapPin,
  ChevronRight,
  Filter,
  Image as ImageIcon
} from 'lucide-react'
import Link from 'next/link'
import { Navbar } from '@/components/layout/navbar'
import { ParticleBackground } from '@/components/effects/particle-background'
import { GlowCard } from '@/components/ui/glow-card'
import { useMatches, useMaps, useSeasons } from '@/hooks/use-supabase'
import { CardSkeleton } from '@/components/ui/loading-skeleton'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import type { Match } from '@/lib/types/database'

export default function PartidasPage() {
  const { matches, loading } = useMatches()
  const { maps } = useMaps()
  const { seasons, activeSeason } = useSeasons()
  
  const [selectedStatus, setSelectedStatus] = useState<string | null>(null)
  const [selectedMap, setSelectedMap] = useState<string | null>(null)

  const filteredMatches = matches.filter(m => {
    if (selectedStatus && m.status !== selectedStatus) return false
    if (selectedMap && m.map_id !== selectedMap) return false
    return true
  })

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'finished': return 'bg-green-500/20 text-green-500'
      case 'in_progress': return 'bg-yellow-500/20 text-yellow-500'
      default: return 'bg-gray-500/20 text-gray-500'
    }
  }

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'finished': return 'Finalizada'
      case 'in_progress': return 'Em andamento'
      default: return 'Pendente'
    }
  }

  return (
    <div className="min-h-screen bg-background relative">
      <ParticleBackground />
      <Navbar />

      <main className="relative z-10 pt-24 px-4 pb-20">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
          >
            <h1 className="text-3xl sm:text-4xl font-black mb-2">
              Historico de <span className="text-primary">Partidas</span>
            </h1>
            <p className="text-muted-foreground">
              {activeSeason?.name || 'Temporada atual'} • {filteredMatches.length} partidas
            </p>
          </motion.div>

          {/* Filters */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="glass rounded-xl p-4 mb-6"
          >
            <div className="flex items-center gap-2 mb-3">
              <Filter className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm text-muted-foreground">Filtros</span>
            </div>
            <div className="flex flex-wrap gap-2">
              <Button
                variant={selectedStatus === null ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedStatus(null)}
                className={cn(selectedStatus === null && "bg-primary text-primary-foreground")}
              >
                Todas
              </Button>
              {['finished', 'in_progress', 'pending'].map(status => (
                <Button
                  key={status}
                  variant={selectedStatus === status ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setSelectedStatus(status)}
                  className={cn(selectedStatus === status && "bg-primary text-primary-foreground")}
                >
                  {getStatusLabel(status)}
                </Button>
              ))}
            </div>
          </motion.div>

          {/* Matches List */}
          {loading ? (
            <div className="grid gap-4">
              {[1, 2, 3, 4, 5].map(i => <CardSkeleton key={i} />)}
            </div>
          ) : filteredMatches.length === 0 ? (
            <GlowCard className="text-center py-12">
              <Swords className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <p className="text-xl font-bold mb-2">Nenhuma partida encontrada</p>
              <p className="text-muted-foreground">
                {selectedStatus || selectedMap ? 'Tente ajustar os filtros' : 'As partidas aparecerão aqui'}
              </p>
            </GlowCard>
          ) : (
            <div className="space-y-4">
              {filteredMatches.map((match, index) => (
                <motion.div
                  key={match.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                >
                  <Link href={`/partidas/${match.id}`}>
                    <GlowCard className="cursor-pointer">
                      <div className="flex flex-col lg:flex-row lg:items-center gap-4">
                        {/* Match Info */}
                        <div className="flex items-center gap-4 flex-1">
                          {/* Date */}
                          <div className="text-center min-w-[60px]">
                            <Calendar className="w-4 h-4 text-muted-foreground mx-auto mb-1" />
                            <p className="text-xs text-muted-foreground">
                              {new Date(match.match_date).toLocaleDateString('pt-BR', { 
                                day: '2-digit', 
                                month: 'short' 
                              })}
                            </p>
                          </div>

                          {/* Map */}
                          <div className="flex items-center gap-2">
                            <MapPin className="w-4 h-4 text-primary" />
                            <span className="font-medium">{match.map?.name || 'Mapa'}</span>
                          </div>

                          {/* Status */}
                          <span className={cn(
                            "px-2 py-1 rounded-full text-xs font-medium",
                            getStatusColor(match.status)
                          )}>
                            {getStatusLabel(match.status)}
                          </span>

                          {match.is_overtime && (
                            <span className="px-2 py-1 rounded-full text-xs font-medium bg-orange-500/20 text-orange-500">
                              OT
                            </span>
                          )}
                        </div>

                        {/* Score */}
                        <div className="flex items-center justify-center gap-4">
                          <div className={cn(
                            "text-center px-4 py-2 rounded-lg",
                            match.winner === 'TEAM_A' ? "bg-green-500/20" : "bg-secondary"
                          )}>
                            <p className="text-xs text-muted-foreground mb-1">TIME A</p>
                            <p className={cn(
                              "text-3xl font-black",
                              match.winner === 'TEAM_A' ? "text-green-500" : "text-foreground"
                            )}>
                              {match.team_a_score}
                            </p>
                            {match.team_a_side && (
                              <p className="text-xs text-muted-foreground">{match.team_a_side}</p>
                            )}
                          </div>

                          <span className="text-2xl text-muted-foreground font-bold">x</span>

                          <div className={cn(
                            "text-center px-4 py-2 rounded-lg",
                            match.winner === 'TEAM_B' ? "bg-green-500/20" : "bg-secondary"
                          )}>
                            <p className="text-xs text-muted-foreground mb-1">TIME B</p>
                            <p className={cn(
                              "text-3xl font-black",
                              match.winner === 'TEAM_B' ? "text-green-500" : "text-foreground"
                            )}>
                              {match.team_b_score}
                            </p>
                            {match.team_b_side && (
                              <p className="text-xs text-muted-foreground">{match.team_b_side}</p>
                            )}
                          </div>
                        </div>

                        {/* MVP & Arrow */}
                        <div className="flex items-center gap-4 lg:min-w-[200px] justify-end">
                          {match.mvp_player && (
                            <div className="flex items-center gap-2">
                              <Trophy className="w-4 h-4 text-primary" />
                              <span className="text-sm text-muted-foreground">MVP:</span>
                              <span className="text-sm font-medium text-primary">
                                {match.mvp_player.nickname}
                              </span>
                            </div>
                          )}
                          
                          {match.image_url && (
                            <ImageIcon className="w-4 h-4 text-muted-foreground" />
                          )}

                          <ChevronRight className="w-5 h-5 text-muted-foreground" />
                        </div>
                      </div>
                    </GlowCard>
                  </Link>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  )
}
