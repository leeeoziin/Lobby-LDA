'use client'

import { useEffect, useState } from 'react'
import { useParams } from 'next/navigation'
import { motion } from 'framer-motion'
import { 
  ArrowLeft,
  Trophy, 
  Calendar,
  MapPin,
  Swords,
  Shield,
  Target,
  Skull,
  Hand,
  Image as ImageIcon,
  ExternalLink
} from 'lucide-react'
import Link from 'next/link'
import { Navbar } from '@/components/layout/navbar'
import { ParticleBackground } from '@/components/effects/particle-background'
import { GlowCard } from '@/components/ui/glow-card'
import { createClient } from '@/lib/supabase/client'
import { CardSkeleton } from '@/components/ui/loading-skeleton'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import type { Match, MatchPlayer } from '@/lib/types/database'

const supabase = createClient()

export default function MatchDetailPage() {
  const params = useParams()
  const matchId = params.id as string
  
  const [match, setMatch] = useState<Match | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchMatch() {
      const { data, error } = await supabase
        .from('matches')
        .select(`
          *,
          map:maps(*),
          mvp_player:players!matches_mvp_player_id_fkey(*),
          match_players(
            *,
            player:players(*)
          )
        `)
        .eq('id', matchId)
        .single()

      if (!error && data) {
        setMatch(data)
      }
      setLoading(false)
    }

    if (matchId) {
      fetchMatch()
    }
  }, [matchId])

  const teamAPlayers = match?.match_players?.filter(mp => mp.team === 'TEAM_A') || []
  const teamBPlayers = match?.match_players?.filter(mp => mp.team === 'TEAM_B') || []

  const getKD = (mp: MatchPlayer) => {
    return mp.deaths > 0 ? (mp.kills / mp.deaths).toFixed(2) : mp.kills.toString()
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'finished': return 'bg-green-500/20 text-green-500'
      case 'in_progress': return 'bg-yellow-500/20 text-yellow-500'
      default: return 'bg-gray-500/20 text-gray-500'
    }
  }

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'finished': return 'Finalizada'
      case 'in_progress': return 'Em andamento'
      default: return 'Pendente'
    }
  }

  return (
    <div className="min-h-screen bg-background relative">
      <ParticleBackground />
      <Navbar />

      <main className="relative z-10 pt-24 px-4 pb-20">
        <div className="max-w-6xl mx-auto">
          {/* Back Button */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="mb-6"
          >
            <Link href="/partidas">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Voltar
              </Button>
            </Link>
          </motion.div>

          {loading ? (
            <div className="space-y-4">
              <CardSkeleton />
              <div className="grid md:grid-cols-2 gap-4">
                <CardSkeleton />
                <CardSkeleton />
              </div>
            </div>
          ) : !match ? (
            <GlowCard className="text-center py-12">
              <Swords className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <p className="text-xl font-bold">Partida nao encontrada</p>
            </GlowCard>
          ) : (
            <>
              {/* Match Header */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <GlowCard className="mb-6">
                  <div className="flex flex-wrap items-center gap-4 mb-6">
                    <div className="flex items-center gap-2">
                      <MapPin className="w-5 h-5 text-primary" />
                      <span className="font-bold text-lg">{match.map?.name || 'Mapa'}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-muted-foreground" />
                      <span className="text-muted-foreground">
                        {new Date(match.match_date).toLocaleDateString('pt-BR', {
                          day: '2-digit',
                          month: 'long',
                          year: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </span>
                    </div>
                    <span className={cn(
                      "px-3 py-1 rounded-full text-sm font-medium",
                      getStatusColor(match.status)
                    )}>
                      {getStatusLabel(match.status)}
                    </span>
                    {match.is_overtime && (
                      <span className="px-3 py-1 rounded-full text-sm font-medium bg-orange-500/20 text-orange-500">
                        Overtime
                      </span>
                    )}
                  </div>

                  {/* Score */}
                  <div className="flex items-center justify-center gap-8 py-8">
                    <div className={cn(
                      "text-center p-6 rounded-2xl flex-1 max-w-[200px]",
                      match.winner === 'TEAM_A' ? "bg-green-500/20 border-2 border-green-500" : "bg-secondary"
                    )}>
                      <p className="text-sm text-muted-foreground mb-2">TIME A</p>
                      <p className={cn(
                        "text-6xl font-black",
                        match.winner === 'TEAM_A' ? "text-green-500" : "text-foreground"
                      )}>
                        {match.team_a_score}
                      </p>
                      {match.team_a_side && (
                        <div className="flex items-center justify-center gap-2 mt-2">
                          {match.team_a_side === 'ATAQUE' ? (
                            <Swords className="w-4 h-4 text-red-500" />
                          ) : (
                            <Shield className="w-4 h-4 text-blue-500" />
                          )}
                          <span className="text-sm text-muted-foreground">{match.team_a_side}</span>
                        </div>
                      )}
                      {match.winner === 'TEAM_A' && (
                        <p className="text-xs text-green-500 font-medium mt-2">VITORIA</p>
                      )}
                    </div>

                    <span className="text-4xl text-muted-foreground font-bold">x</span>

                    <div className={cn(
                      "text-center p-6 rounded-2xl flex-1 max-w-[200px]",
                      match.winner === 'TEAM_B' ? "bg-green-500/20 border-2 border-green-500" : "bg-secondary"
                    )}>
                      <p className="text-sm text-muted-foreground mb-2">TIME B</p>
                      <p className={cn(
                        "text-6xl font-black",
                        match.winner === 'TEAM_B' ? "text-green-500" : "text-foreground"
                      )}>
                        {match.team_b_score}
                      </p>
                      {match.team_b_side && (
                        <div className="flex items-center justify-center gap-2 mt-2">
                          {match.team_b_side === 'ATAQUE' ? (
                            <Swords className="w-4 h-4 text-red-500" />
                          ) : (
                            <Shield className="w-4 h-4 text-blue-500" />
                          )}
                          <span className="text-sm text-muted-foreground">{match.team_b_side}</span>
                        </div>
                      )}
                      {match.winner === 'TEAM_B' && (
                        <p className="text-xs text-green-500 font-medium mt-2">VITORIA</p>
                      )}
                    </div>
                  </div>

                  {/* MVP */}
                  {match.mvp_player && (
                    <div className="flex items-center justify-center gap-3 py-4 border-t border-border">
                      <Trophy className="w-6 h-6 text-primary" />
                      <span className="text-muted-foreground">MVP da Partida:</span>
                      <Link href={`/jogador/${match.mvp_player.nickname}`}>
                        <span className="font-bold text-primary hover:underline">
                          {match.mvp_player.nickname}
                        </span>
                      </Link>
                    </div>
                  )}
                </GlowCard>
              </motion.div>

              {/* Teams */}
              <div className="grid md:grid-cols-2 gap-6">
                {/* Team A */}
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.1 }}
                >
                  <GlowCard glowColor={match.winner === 'TEAM_A' ? 'gold' : 'yellow'}>
                    <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                      <span className={cn(
                        "w-3 h-3 rounded-full",
                        match.winner === 'TEAM_A' ? "bg-green-500" : "bg-red-500"
                      )} />
                      TIME A
                      {match.winner === 'TEAM_A' && (
                        <span className="text-xs bg-green-500/20 text-green-500 px-2 py-1 rounded-full ml-auto">
                          Vencedor
                        </span>
                      )}
                    </h2>

                    <div className="space-y-3">
                      {teamAPlayers.map((mp, i) => (
                        <motion.div
                          key={mp.id}
                          initial={{ opacity: 0, x: -10 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: 0.2 + i * 0.05 }}
                          className={cn(
                            "glass-dark rounded-lg p-4",
                            mp.is_mvp && "border border-primary/50"
                          )}
                        >
                          <div className="flex items-center gap-3 mb-3">
                            <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                              <span className="font-bold text-primary">
                                {mp.player?.nickname?.charAt(0).toUpperCase() || '?'}
                              </span>
                            </div>
                            <div className="flex-1">
                              <Link href={`/jogador/${mp.player?.nickname}`}>
                                <p className="font-medium hover:text-primary transition-colors">
                                  {mp.player?.nickname || 'Jogador'}
                                </p>
                              </Link>
                              <p className="text-xs text-muted-foreground">{mp.player?.platform}</p>
                            </div>
                            {mp.is_mvp && (
                              <Trophy className="w-5 h-5 text-primary" />
                            )}
                          </div>

                          <div className="grid grid-cols-4 gap-2 text-center text-sm">
                            <div>
                              <p className="text-muted-foreground text-xs">Kills</p>
                              <p className="font-bold text-green-500">{mp.kills}</p>
                            </div>
                            <div>
                              <p className="text-muted-foreground text-xs">Mortes</p>
                              <p className="font-bold text-red-500">{mp.deaths}</p>
                            </div>
                            <div>
                              <p className="text-muted-foreground text-xs">Assists</p>
                              <p className="font-bold text-blue-500">{mp.assists}</p>
                            </div>
                            <div>
                              <p className="text-muted-foreground text-xs">K/D</p>
                              <p className={cn(
                                "font-bold",
                                parseFloat(getKD(mp)) >= 1 ? "text-green-500" : "text-red-500"
                              )}>
                                {getKD(mp)}
                              </p>
                            </div>
                          </div>

                          {(mp.entry_kills > 0 || mp.clutches > 0) && (
                            <div className="flex gap-4 mt-3 pt-3 border-t border-border/50 text-xs">
                              {mp.entry_kills > 0 && (
                                <span className="text-muted-foreground">
                                  Entry Kills: <span className="text-foreground">{mp.entry_kills}</span>
                                </span>
                              )}
                              {mp.clutches > 0 && (
                                <span className="text-muted-foreground">
                                  Clutches: <span className="text-foreground">{mp.clutches}</span>
                                </span>
                              )}
                            </div>
                          )}
                        </motion.div>
                      ))}
                    </div>
                  </GlowCard>
                </motion.div>

                {/* Team B */}
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.1 }}
                >
                  <GlowCard glowColor={match.winner === 'TEAM_B' ? 'gold' : 'yellow'}>
                    <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                      <span className={cn(
                        "w-3 h-3 rounded-full",
                        match.winner === 'TEAM_B' ? "bg-green-500" : "bg-blue-500"
                      )} />
                      TIME B
                      {match.winner === 'TEAM_B' && (
                        <span className="text-xs bg-green-500/20 text-green-500 px-2 py-1 rounded-full ml-auto">
                          Vencedor
                        </span>
                      )}
                    </h2>

                    <div className="space-y-3">
                      {teamBPlayers.map((mp, i) => (
                        <motion.div
                          key={mp.id}
                          initial={{ opacity: 0, x: 10 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: 0.2 + i * 0.05 }}
                          className={cn(
                            "glass-dark rounded-lg p-4",
                            mp.is_mvp && "border border-primary/50"
                          )}
                        >
                          <div className="flex items-center gap-3 mb-3">
                            <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                              <span className="font-bold text-primary">
                                {mp.player?.nickname?.charAt(0).toUpperCase() || '?'}
                              </span>
                            </div>
                            <div className="flex-1">
                              <Link href={`/jogador/${mp.player?.nickname}`}>
                                <p className="font-medium hover:text-primary transition-colors">
                                  {mp.player?.nickname || 'Jogador'}
                                </p>
                              </Link>
                              <p className="text-xs text-muted-foreground">{mp.player?.platform}</p>
                            </div>
                            {mp.is_mvp && (
                              <Trophy className="w-5 h-5 text-primary" />
                            )}
                          </div>

                          <div className="grid grid-cols-4 gap-2 text-center text-sm">
                            <div>
                              <p className="text-muted-foreground text-xs">Kills</p>
                              <p className="font-bold text-green-500">{mp.kills}</p>
                            </div>
                            <div>
                              <p className="text-muted-foreground text-xs">Mortes</p>
                              <p className="font-bold text-red-500">{mp.deaths}</p>
                            </div>
                            <div>
                              <p className="text-muted-foreground text-xs">Assists</p>
                              <p className="font-bold text-blue-500">{mp.assists}</p>
                            </div>
                            <div>
                              <p className="text-muted-foreground text-xs">K/D</p>
                              <p className={cn(
                                "font-bold",
                                parseFloat(getKD(mp)) >= 1 ? "text-green-500" : "text-red-500"
                              )}>
                                {getKD(mp)}
                              </p>
                            </div>
                          </div>

                          {(mp.entry_kills > 0 || mp.clutches > 0) && (
                            <div className="flex gap-4 mt-3 pt-3 border-t border-border/50 text-xs">
                              {mp.entry_kills > 0 && (
                                <span className="text-muted-foreground">
                                  Entry Kills: <span className="text-foreground">{mp.entry_kills}</span>
                                </span>
                              )}
                              {mp.clutches > 0 && (
                                <span className="text-muted-foreground">
                                  Clutches: <span className="text-foreground">{mp.clutches}</span>
                                </span>
                              )}
                            </div>
                          )}
                        </motion.div>
                      ))}
                    </div>
                  </GlowCard>
                </motion.div>
              </div>

              {/* Match Screenshot */}
              {(match.image_url || match.screenshot_url) && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                  className="mt-6"
                >
                  <GlowCard>
                    <div className="flex items-center gap-2 mb-4">
                      <ImageIcon className="w-5 h-5 text-primary" />
                      <h2 className="font-bold">Screenshot da Partida</h2>
                    </div>
                    <a 
                      href={match.image_url || match.screenshot_url || '#'}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="block"
                    >
                      <img 
                        src={match.image_url || match.screenshot_url || ''}
                        alt="Screenshot da partida"
                        className="w-full rounded-lg border border-border hover:border-primary/50 transition-colors"
                      />
                    </a>
                  </GlowCard>
                </motion.div>
              )}
            </>
          )}
        </div>
      </main>
    </div>
  )
}
