'use client'

import { motion } from 'framer-motion'
import { Users, Swords, Target, Trophy, ChevronRight, Crown, Medal, Award } from 'lucide-react'
import Link from 'next/link'
import { Navbar } from '@/components/layout/navbar'
import { ParticleBackground } from '@/components/effects/particle-background'
import { StatCard } from '@/components/ui/stat-card'
import { GlowCard } from '@/components/ui/glow-card'
import { usePlayers, useMatches, useGlobalStats } from '@/hooks/use-supabase'
import { TableSkeleton, CardSkeleton } from '@/components/ui/loading-skeleton'

export default function HomePage() {
  const { players, loading: playersLoading } = usePlayers()
  const { matches, loading: matchesLoading } = useMatches()
  const { stats, loading: statsLoading } = useGlobalStats()

  const topPlayers = players.slice(0, 5)
  const recentMatches = matches.slice(0, 3)

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      <ParticleBackground />
      <Navbar />
      
      <main className="relative z-10 pt-20">
        {/* Hero Section */}
        <section className="relative min-h-[80vh] flex items-center justify-center px-4 py-20">
          {/* Gradient Overlay */}
          <div className="absolute inset-0 bg-gradient-radial pointer-events-none" />
          
          <div className="max-w-6xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8 }}
              className="mb-8"
            >
              <div className="inline-flex items-center justify-center w-32 h-32 rounded-2xl bg-primary glow-yellow-lg mb-6">
                <span className="text-5xl font-black text-primary-foreground">LDA</span>
              </div>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="text-4xl sm:text-6xl lg:text-7xl font-black mb-6 text-balance"
            >
              <span className="text-foreground">Lobby </span>
              <span className="text-primary text-glow-lg">Premium</span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto mb-10 text-pretty"
            >
              Plataforma competitiva de alto nivel para Rainbow Six Siege. 
              Matchmaking automatico, rankings em tempo real e estatisticas avancadas.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.6 }}
              className="flex flex-col sm:flex-row gap-4 justify-center"
            >
              <Link href="/lobby">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-8 py-4 bg-primary text-primary-foreground rounded-xl font-bold text-lg glow-yellow flex items-center gap-2 justify-center"
                >
                  <Users className="w-5 h-5" />
                  Entrar no Lobby
                </motion.button>
              </Link>
              <Link href="/ranking">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-8 py-4 bg-secondary text-secondary-foreground rounded-xl font-bold text-lg border border-border hover:border-primary/50 flex items-center gap-2 justify-center"
                >
                  <Trophy className="w-5 h-5" />
                  Ver Ranking
                </motion.button>
              </Link>
            </motion.div>
          </div>
        </section>

        {/* Global Stats Section */}
        <section className="px-4 py-16">
          <div className="max-w-6xl mx-auto">
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-2xl sm:text-3xl font-bold text-center mb-10"
            >
              Estatisticas <span className="text-primary">Globais</span>
            </motion.h2>

            {statsLoading ? (
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                {[1,2,3,4].map(i => <CardSkeleton key={i} />)}
              </div>
            ) : (
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <StatCard 
                  label="Jogadores" 
                  value={stats.totalPlayers}
                  icon={Users}
                  delay={0}
                />
                <StatCard 
                  label="Partidas" 
                  value={stats.totalMatches}
                  icon={Swords}
                  delay={0.1}
                />
                <StatCard 
                  label="Total de Kills" 
                  value={stats.totalKills.toLocaleString()}
                  icon={Target}
                  delay={0.2}
                />
                <StatCard 
                  label="MVP da Temporada" 
                  value={stats.mvpPlayer?.nickname || '-'}
                  icon={Trophy}
                  delay={0.3}
                />
              </div>
            )}
          </div>
        </section>

        {/* Top Ranking Preview */}
        <section className="px-4 py-16">
          <div className="max-w-6xl mx-auto">
            <div className="flex items-center justify-between mb-8">
              <motion.h2
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                className="text-2xl sm:text-3xl font-bold"
              >
                Top <span className="text-primary">Ranking</span>
              </motion.h2>
              <Link href="/ranking">
                <motion.span
                  whileHover={{ x: 5 }}
                  className="text-primary flex items-center gap-1 text-sm font-medium"
                >
                  Ver completo <ChevronRight className="w-4 h-4" />
                </motion.span>
              </Link>
            </div>

            {playersLoading ? (
              <TableSkeleton rows={5} />
            ) : (
              <div className="space-y-3">
                {topPlayers.map((player, index) => (
                  <motion.div
                    key={player.id}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <Link href={`/jogador/${player.nickname}`}>
                      <GlowCard 
                        className="flex items-center gap-4 cursor-pointer"
                        glowColor={index === 0 ? 'gold' : index === 1 ? 'silver' : index === 2 ? 'bronze' : 'yellow'}
                      >
                        {/* Position */}
                        <div className="flex-shrink-0 w-12 h-12 rounded-lg flex items-center justify-center bg-secondary">
                          {index === 0 ? (
                            <Crown className="w-6 h-6 text-yellow-500" />
                          ) : index === 1 ? (
                            <Medal className="w-6 h-6 text-gray-400" />
                          ) : index === 2 ? (
                            <Award className="w-6 h-6 text-amber-600" />
                          ) : (
                            <span className="text-xl font-bold text-muted-foreground">#{index + 1}</span>
                          )}
                        </div>

                        {/* Avatar */}
                        <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center">
                          <span className="text-lg font-bold text-primary">
                            {player.nickname.charAt(0).toUpperCase()}
                          </span>
                        </div>

                        {/* Info */}
                        <div className="flex-1 min-w-0">
                          <p className="font-bold text-foreground truncate">{player.nickname}</p>
                          <p className="text-sm text-muted-foreground">
                            {player.platform} • ELO {player.elo}
                          </p>
                        </div>

                        {/* Stats */}
                        <div className="hidden sm:flex items-center gap-6 text-sm">
                          <div className="text-center">
                            <p className="text-muted-foreground">K/D</p>
                            <p className="font-bold text-foreground">
                              {player.deaths > 0 ? (player.kills / player.deaths).toFixed(2) : player.kills}
                            </p>
                          </div>
                          <div className="text-center">
                            <p className="text-muted-foreground">Vitorias</p>
                            <p className="font-bold text-green-500">{player.wins}</p>
                          </div>
                          <div className="text-center">
                            <p className="text-muted-foreground">Pontos</p>
                            <p className="font-bold text-primary">{player.points}</p>
                          </div>
                        </div>

                        <ChevronRight className="w-5 h-5 text-muted-foreground" />
                      </GlowCard>
                    </Link>
                  </motion.div>
                ))}
              </div>
            )}
          </div>
        </section>

        {/* Recent Matches */}
        <section className="px-4 py-16 pb-32">
          <div className="max-w-6xl mx-auto">
            <div className="flex items-center justify-between mb-8">
              <motion.h2
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                className="text-2xl sm:text-3xl font-bold"
              >
                Ultimas <span className="text-primary">Partidas</span>
              </motion.h2>
              <Link href="/partidas">
                <motion.span
                  whileHover={{ x: 5 }}
                  className="text-primary flex items-center gap-1 text-sm font-medium"
                >
                  Ver todas <ChevronRight className="w-4 h-4" />
                </motion.span>
              </Link>
            </div>

            {matchesLoading ? (
              <div className="grid md:grid-cols-3 gap-4">
                {[1,2,3].map(i => <CardSkeleton key={i} />)}
              </div>
            ) : recentMatches.length === 0 ? (
              <GlowCard className="text-center py-12">
                <Swords className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">Nenhuma partida registrada ainda</p>
              </GlowCard>
            ) : (
              <div className="grid md:grid-cols-3 gap-4">
                {recentMatches.map((match, index) => (
                  <motion.div
                    key={match.id}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <Link href={`/partidas/${match.id}`}>
                      <GlowCard className="cursor-pointer h-full">
                        <div className="flex items-center justify-between mb-4">
                          <span className="text-xs text-muted-foreground">
                            {new Date(match.match_date).toLocaleDateString('pt-BR')}
                          </span>
                          <span className={`text-xs px-2 py-1 rounded-full ${
                            match.status === 'finished' 
                              ? 'bg-green-500/20 text-green-500' 
                              : match.status === 'in_progress'
                              ? 'bg-yellow-500/20 text-yellow-500'
                              : 'bg-gray-500/20 text-gray-500'
                          }`}>
                            {match.status === 'finished' ? 'Finalizada' : match.status === 'in_progress' ? 'Em andamento' : 'Pendente'}
                          </span>
                        </div>

                        <div className="text-center mb-4">
                          <p className="text-sm text-muted-foreground mb-2">{match.map?.name || 'Mapa'}</p>
                          <div className="flex items-center justify-center gap-4">
                            <div className="text-center">
                              <p className="text-xs text-muted-foreground">TIME A</p>
                              <p className={`text-3xl font-black ${match.winner === 'TEAM_A' ? 'text-green-500' : 'text-foreground'}`}>
                                {match.team_a_score}
                              </p>
                            </div>
                            <span className="text-2xl text-muted-foreground">x</span>
                            <div className="text-center">
                              <p className="text-xs text-muted-foreground">TIME B</p>
                              <p className={`text-3xl font-black ${match.winner === 'TEAM_B' ? 'text-green-500' : 'text-foreground'}`}>
                                {match.team_b_score}
                              </p>
                            </div>
                          </div>
                        </div>

                        {match.mvp_player && (
                          <div className="flex items-center justify-center gap-2 text-sm">
                            <Trophy className="w-4 h-4 text-primary" />
                            <span className="text-muted-foreground">MVP:</span>
                            <span className="text-primary font-medium">{match.mvp_player.nickname}</span>
                          </div>
                        )}
                      </GlowCard>
                    </Link>
                  </motion.div>
                ))}
              </div>
            )}
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="relative z-10 border-t border-border py-8 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <p className="text-sm text-muted-foreground">
            LDA Lobby Premium &copy; {new Date().getFullYear()} - Rainbow Six Siege
          </p>
        </div>
      </footer>
    </div>
  )
}
