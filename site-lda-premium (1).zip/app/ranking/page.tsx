'use client'

import { useState, useMemo } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  Search, 
  ChevronUp, 
  ChevronDown, 
  Crown, 
  Medal, 
  Award,
  Filter,
  X,
  TrendingUp,
  TrendingDown,
  Minus
} from 'lucide-react'
import { Navbar } from '@/components/layout/navbar'
import { ParticleBackground } from '@/components/effects/particle-background'
import { usePlayers, useSeasons, useMaps } from '@/hooks/use-supabase'
import { TableSkeleton } from '@/components/ui/loading-skeleton'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import Link from 'next/link'
import { RankBadge } from '@/components/ui/rank-badge'
import type { Player } from '@/lib/types/database'

type SortKey = keyof Player | 'kd' | 'winrate'
type SortDirection = 'asc' | 'desc'

const columns = [
  { key: 'position', label: '#', sortable: false },
  { key: 'nickname', label: 'Jogador', sortable: true },
  { key: 'points', label: 'Pts', sortable: true },
  { key: 'elo', label: 'ELO', sortable: true },
  { key: 'kills', label: 'Kills', sortable: true },
  { key: 'deaths', label: 'Mortes', sortable: true },
  { key: 'assists', label: 'Assists', sortable: true },
  { key: 'kd', label: 'K/D', sortable: true },
  { key: 'kost', label: 'KOST', sortable: true },
  { key: 'matches_played', label: 'Partidas', sortable: true },
  { key: 'wins', label: 'V', sortable: true },
  { key: 'wins_ot', label: 'V-OT', sortable: true },
  { key: 'losses_ot', label: 'D-OT', sortable: true },
  { key: 'losses', label: 'D', sortable: true },
  { key: 'winrate', label: 'Win%', sortable: true },
  { key: 'mvp_count', label: 'MVPs', sortable: true },
  { key: 'current_streak', label: 'Streak', sortable: true },
]

export default function RankingPage() {
  const { players, loading } = usePlayers()
  const { seasons, activeSeason } = useSeasons()
  
  const [search, setSearch] = useState('')
  const [sortKey, setSortKey] = useState<SortKey>('points')
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc')
  const [selectedPlatform, setSelectedPlatform] = useState<string | null>(null)
  const [showFilters, setShowFilters] = useState(false)
  const [currentPage, setCurrentPage] = useState(1)
  const itemsPerPage = 20

  const filteredAndSortedPlayers = useMemo(() => {
    let result = [...players]

    // Filter by search
    if (search) {
      result = result.filter(p => 
        p.nickname.toLowerCase().includes(search.toLowerCase())
      )
    }

    // Filter by platform
    if (selectedPlatform) {
      result = result.filter(p => p.platform === selectedPlatform)
    }

    // Sort
    result.sort((a, b) => {
      let aVal: number
      let bVal: number

      if (sortKey === 'kd') {
        aVal = a.deaths > 0 ? a.kills / a.deaths : a.kills
        bVal = b.deaths > 0 ? b.kills / b.deaths : b.kills
      } else if (sortKey === 'winrate') {
        aVal = a.matches_played > 0 ? (a.wins / a.matches_played) * 100 : 0
        bVal = b.matches_played > 0 ? (b.wins / b.matches_played) * 100 : 0
      } else if (sortKey === 'nickname') {
        return sortDirection === 'asc' 
          ? a.nickname.localeCompare(b.nickname)
          : b.nickname.localeCompare(a.nickname)
      } else {
        aVal = (a[sortKey as keyof Player] as number) || 0
        bVal = (b[sortKey as keyof Player] as number) || 0
      }

      return sortDirection === 'asc' ? aVal - bVal : bVal - aVal
    })

    return result
  }, [players, search, sortKey, sortDirection, selectedPlatform])

  const totalPages = Math.ceil(filteredAndSortedPlayers.length / itemsPerPage)
  const paginatedPlayers = filteredAndSortedPlayers.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  )

  const handleSort = (key: string) => {
    const column = columns.find(c => c.key === key)
    if (!column?.sortable) return

    if (sortKey === key) {
      setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc')
    } else {
      setSortKey(key as SortKey)
      setSortDirection('desc')
    }
  }

  const getKD = (p: Player) => p.deaths > 0 ? (p.kills / p.deaths).toFixed(2) : p.kills.toString()
  const getWinRate = (p: Player) => p.matches_played > 0 ? ((p.wins / p.matches_played) * 100).toFixed(1) : '0'

  const getPositionStyle = (index: number) => {
    const actualPosition = (currentPage - 1) * itemsPerPage + index
    if (actualPosition === 0) return 'bg-gradient-to-r from-yellow-500/20 to-transparent border-l-4 border-yellow-500'
    if (actualPosition === 1) return 'bg-gradient-to-r from-gray-400/20 to-transparent border-l-4 border-gray-400'
    if (actualPosition === 2) return 'bg-gradient-to-r from-amber-600/20 to-transparent border-l-4 border-amber-600'
    return ''
  }

  return (
    <div className="min-h-screen bg-background relative">
      <ParticleBackground />
      <Navbar />

      <main className="relative z-10 pt-24 px-4 pb-20">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
          >
            <h1 className="text-3xl sm:text-4xl font-black mb-2">
              Ranking <span className="text-primary">Competitivo</span>
            </h1>
            <p className="text-muted-foreground">
              {activeSeason?.name || 'Temporada atual'} • {filteredAndSortedPlayers.length} jogadores
            </p>
          </motion.div>

          {/* Search and Filters */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="glass rounded-xl p-4 mb-6"
          >
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input
                  type="text"
                  placeholder="Buscar jogador..."
                  value={search}
                  onChange={(e) => {
                    setSearch(e.target.value)
                    setCurrentPage(1)
                  }}
                  className="pl-10 bg-secondary border-border"
                />
              </div>
              <Button
                variant="outline"
                onClick={() => setShowFilters(!showFilters)}
                className={cn(
                  "border-border",
                  showFilters && "border-primary text-primary"
                )}
              >
                <Filter className="w-4 h-4 mr-2" />
                Filtros
              </Button>
            </div>

            <AnimatePresence>
              {showFilters && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="overflow-hidden"
                >
                  <div className="pt-4 mt-4 border-t border-border">
                    <p className="text-sm text-muted-foreground mb-3">Plataforma</p>
                    <div className="flex flex-wrap gap-2">
                      {['PC', 'Xbox', 'PSN'].map(platform => (
                        <Button
                          key={platform}
                          variant={selectedPlatform === platform ? 'default' : 'outline'}
                          size="sm"
                          onClick={() => {
                            setSelectedPlatform(prev => prev === platform ? null : platform)
                            setCurrentPage(1)
                          }}
                          className={cn(
                            selectedPlatform === platform && "bg-primary text-primary-foreground"
                          )}
                        >
                          {platform}
                          {selectedPlatform === platform && (
                            <X className="w-3 h-3 ml-1" />
                          )}
                        </Button>
                      ))}
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>

          {/* Table */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="glass rounded-xl overflow-hidden"
          >
            {loading ? (
              <div className="p-4">
                <TableSkeleton rows={10} />
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full min-w-[1200px]">
                  <thead>
                    <tr className="border-b border-border">
                      {columns.map(col => (
                        <th
                          key={col.key}
                          onClick={() => handleSort(col.key)}
                          className={cn(
                            "px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider",
                            col.sortable && "cursor-pointer hover:text-foreground transition-colors",
                            col.key === 'nickname' && "sticky left-0 bg-card z-10"
                          )}
                        >
                          <div className="flex items-center gap-1">
                            {col.label}
                            {col.sortable && sortKey === col.key && (
                              sortDirection === 'asc' 
                                ? <ChevronUp className="w-4 h-4" />
                                : <ChevronDown className="w-4 h-4" />
                            )}
                          </div>
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {paginatedPlayers.map((player, index) => {
                      const actualPosition = (currentPage - 1) * itemsPerPage + index
                      return (
                        <motion.tr
                          key={player.id}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: index * 0.02 }}
                          className={cn(
                            "border-b border-border/50 hover:bg-secondary/50 transition-colors",
                            getPositionStyle(index)
                          )}
                        >
                          {/* Position */}
                          <td className="px-4 py-3">
                            <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-secondary">
                              {actualPosition === 0 ? (
                                <Crown className="w-5 h-5 text-yellow-500" />
                              ) : actualPosition === 1 ? (
                                <Medal className="w-5 h-5 text-gray-400" />
                              ) : actualPosition === 2 ? (
                                <Award className="w-5 h-5 text-amber-600" />
                              ) : (
                                <span className="text-sm font-medium text-muted-foreground">
                                  {actualPosition + 1}
                                </span>
                              )}
                            </div>
                          </td>

                          {/* Player */}
                          <td className="px-4 py-3 sticky left-0 bg-card">
                            <Link href={`/jogador/${player.nickname}`}>
                              <div className="flex items-center gap-3 hover:opacity-80 transition-opacity">
                                <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                                  <span className="font-bold text-primary">
                                    {player.nickname.charAt(0).toUpperCase()}
                                  </span>
                                </div>
                                <div>
                                  <p className="font-medium text-foreground">{player.nickname}</p>
                                  <p className="text-xs text-muted-foreground">{player.platform}</p>
                                </div>
                              </div>
                            </Link>
                          </td>

                          {/* Points */}
                          <td className="px-4 py-3">
                            <span className="font-bold text-primary">{player.points}</span>
                          </td>

                          {/* ELO */}
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-2">
                              <RankBadge elo={player.elo} size="sm" />
                            </div>
                          </td>

                          {/* Kills */}
                          <td className="px-4 py-3 text-green-500 font-medium">{player.kills}</td>

                          {/* Deaths */}
                          <td className="px-4 py-3 text-red-500 font-medium">{player.deaths}</td>

                          {/* Assists */}
                          <td className="px-4 py-3 text-blue-500 font-medium">{player.assists}</td>

                          {/* K/D */}
                          <td className="px-4 py-3">
                            <span className={cn(
                              "font-bold",
                              parseFloat(getKD(player)) >= 1 ? "text-green-500" : "text-red-500"
                            )}>
                              {getKD(player)}
                            </span>
                          </td>

                          {/* KOST */}
                          <td className="px-4 py-3">
                            <span className="text-muted-foreground">{player.kost}%</span>
                          </td>

                          {/* Matches */}
                          <td className="px-4 py-3 text-muted-foreground">{player.matches_played}</td>

                          {/* Wins */}
                          <td className="px-4 py-3 text-green-500">{player.wins}</td>

                          {/* Wins OT */}
                          <td className="px-4 py-3 text-green-400">{player.wins_ot}</td>

                          {/* Losses OT */}
                          <td className="px-4 py-3 text-orange-400">{player.losses_ot}</td>

                          {/* Losses */}
                          <td className="px-4 py-3 text-red-500">{player.losses}</td>

                          {/* Win Rate */}
                          <td className="px-4 py-3">
                            <span className={cn(
                              "font-medium",
                              parseFloat(getWinRate(player)) >= 50 ? "text-green-500" : "text-red-500"
                            )}>
                              {getWinRate(player)}%
                            </span>
                          </td>

                          {/* MVPs */}
                          <td className="px-4 py-3">
                            <span className="text-primary font-medium">{player.mvp_count}</span>
                          </td>

                          {/* Streak */}
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-1">
                              {player.current_streak > 0 ? (
                                <>
                                  <TrendingUp className="w-4 h-4 text-green-500" />
                                  <span className="text-green-500 font-medium">+{player.current_streak}</span>
                                </>
                              ) : player.current_streak < 0 ? (
                                <>
                                  <TrendingDown className="w-4 h-4 text-red-500" />
                                  <span className="text-red-500 font-medium">{player.current_streak}</span>
                                </>
                              ) : (
                                <>
                                  <Minus className="w-4 h-4 text-muted-foreground" />
                                  <span className="text-muted-foreground">0</span>
                                </>
                              )}
                            </div>
                          </td>
                        </motion.tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </motion.div>

          {/* Pagination */}
          {totalPages > 1 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex items-center justify-center gap-2 mt-6"
            >
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                disabled={currentPage === 1}
              >
                Anterior
              </Button>
              <div className="flex items-center gap-1">
                {Array.from({ length: Math.min(5, totalPages) }).map((_, i) => {
                  let pageNum: number
                  if (totalPages <= 5) {
                    pageNum = i + 1
                  } else if (currentPage <= 3) {
                    pageNum = i + 1
                  } else if (currentPage >= totalPages - 2) {
                    pageNum = totalPages - 4 + i
                  } else {
                    pageNum = currentPage - 2 + i
                  }
                  
                  return (
                    <Button
                      key={pageNum}
                      variant={currentPage === pageNum ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setCurrentPage(pageNum)}
                      className={cn(
                        "w-10",
                        currentPage === pageNum && "bg-primary text-primary-foreground"
                      )}
                    >
                      {pageNum}
                    </Button>
                  )
                })}
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                disabled={currentPage === totalPages}
              >
                Proximo
              </Button>
            </motion.div>
          )}
        </div>
      </main>
    </div>
  )
}
