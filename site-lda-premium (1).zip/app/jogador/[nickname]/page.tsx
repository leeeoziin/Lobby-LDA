'use client'

import { useEffect, useState } from 'react'
import { useParams } from 'next/navigation'
import { motion } from 'framer-motion'
import { 
  ArrowLeft,
  Trophy,
  Target,
  Skull,
  Hand,
  Swords,
  TrendingUp,
  TrendingDown,
  Minus,
  Calendar,
  Monitor,
  Gamepad2,
  ChevronRight
} from 'lucide-react'
import Link from 'next/link'
import { Navbar } from '@/components/layout/navbar'
import { ParticleBackground } from '@/components/effects/particle-background'
import { GlowCard } from '@/components/ui/glow-card'
import { StatCard } from '@/components/ui/stat-card'
import { createClient } from '@/lib/supabase/client'
import { CardSkeleton } from '@/components/ui/loading-skeleton'
import { Button } from '@/components/ui/button'
import { RankBadge, RankProgress } from '@/components/ui/rank-badge'
import { cn } from '@/lib/utils'
import type { Player, Match, MatchPlayer } from '@/lib/types/database'

const supabase = createClient()

export default function PlayerProfilePage() {
  const params = useParams()
  const nickname = decodeURIComponent(params.nickname as string)
  
  const [player, setPlayer] = useState<Player | null>(null)
  const [recentMatches, setRecentMatches] = useState<(Match & { match_player: MatchPlayer })[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchPlayer() {
      // Get player data
      const { data: playerData, error: playerError } = await supabase
        .from('players')
        .select('*')
        .eq('nickname', nickname)
        .single()

      if (!playerError && playerData) {
        setPlayer(playerData)

        // Get recent matches
        const { data: matchPlayers } = await supabase
          .from('match_players')
          .select(`
            *,
            match:matches(
              *,
              map:maps(*)
            )
          `)
          .eq('player_id', playerData.id)
          .order('created_at', { ascending: false })
          .limit(10)

        if (matchPlayers) {
          const matches = matchPlayers.map(mp => ({
            ...mp.match,
            match_player: mp
          })).filter(m => m.id)
          setRecentMatches(matches as any)
        }
      }
      setLoading(false)
    }

    if (nickname) {
      fetchPlayer()
    }
  }, [nickname])

  const getKD = () => {
    if (!player) return '0'
    return player.deaths > 0 ? (player.kills / player.deaths).toFixed(2) : player.kills.toString()
  }

  const getWinRate = () => {
    if (!player || player.matches_played === 0) return '0'
    return ((player.wins / player.matches_played) * 100).toFixed(1)
  }

  const getAvgKills = () => {
    if (!player || player.matches_played === 0) return '0'
    return (player.kills / player.matches_played).toFixed(1)
  }

  const getAvgDeaths = () => {
    if (!player || player.matches_played === 0) return '0'
    return (player.deaths / player.matches_played).toFixed(1)
  }

  const getAvgAssists = () => {
    if (!player || player.matches_played === 0) return '0'
    return (player.assists / player.matches_played).toFixed(1)
  }

  const getPlatformIcon = (platform: string) => {
    if (platform === 'PC') return Monitor
    return Gamepad2
  }

  return (
    <div className="min-h-screen bg-background relative">
      <ParticleBackground />
      <Navbar />

      <main className="relative z-10 pt-24 px-4 pb-20">
        <div className="max-w-6xl mx-auto">
          {/* Back Button */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="mb-6"
          >
            <Link href="/ranking">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Voltar ao Ranking
              </Button>
            </Link>
          </motion.div>

          {loading ? (
            <div className="space-y-4">
              <CardSkeleton />
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                {[1,2,3,4].map(i => <CardSkeleton key={i} />)}
              </div>
            </div>
          ) : !player ? (
            <GlowCard className="text-center py-12">
              <Skull className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <p className="text-xl font-bold">Jogador nao encontrado</p>
            </GlowCard>
          ) : (
            <>
              {/* Profile Header */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <GlowCard className="mb-6">
                  <div className="flex flex-col md:flex-row items-center gap-6">
                    {/* Avatar */}
                    <div className="relative">
                      <div className="w-32 h-32 rounded-2xl bg-primary/20 flex items-center justify-center glow-yellow">
                        <span className="text-5xl font-black text-primary">
                          {player.nickname.charAt(0).toUpperCase()}
                        </span>
                      </div>
                      {player.current_streak > 0 && (
                        <div className="absolute -top-2 -right-2 w-8 h-8 rounded-full bg-green-500 flex items-center justify-center">
                          <TrendingUp className="w-4 h-4 text-white" />
                        </div>
                      )}
                      {player.current_streak < 0 && (
                        <div className="absolute -top-2 -right-2 w-8 h-8 rounded-full bg-red-500 flex items-center justify-center">
                          <TrendingDown className="w-4 h-4 text-white" />
                        </div>
                      )}
                    </div>

                    {/* Info */}
                    <div className="flex-1 text-center md:text-left">
                      <h1 className="text-3xl font-black mb-2">{player.nickname}</h1>
                      <div className="flex flex-wrap items-center justify-center md:justify-start gap-4 text-muted-foreground">
                        <div className="flex items-center gap-1">
                          {(() => {
                            const Icon = getPlatformIcon(player.platform)
                            return <Icon className="w-4 h-4" />
                          })()}
                          <span>{player.platform}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Trophy className="w-4 h-4 text-primary" />
                          <span>{player.mvp_count} MVPs</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Swords className="w-4 h-4" />
                          <span>{player.matches_played} partidas</span>
                        </div>
                      </div>
                    </div>

                    {/* Rank & ELO */}
                    <div className="text-center">
                      <RankBadge elo={player.elo} showElo size="lg" />
                      <div className="mt-3 w-32">
                        <RankProgress elo={player.elo} />
                      </div>
                    </div>

                    {/* Points */}
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Pontos</p>
                      <p className="text-4xl font-black text-foreground">{player.points}</p>
                    </div>
                  </div>
                </GlowCard>
              </motion.div>

              {/* Stats Grid */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6"
              >
                <StatCard 
                  label="Kills"
                  value={player.kills}
                  icon={Target}
                />
                <StatCard 
                  label="Mortes"
                  value={player.deaths}
                  icon={Skull}
                />
                <StatCard 
                  label="Assists"
                  value={player.assists}
                  icon={Hand}
                />
                <StatCard 
                  label="K/D Ratio"
                  value={getKD()}
                  icon={Swords}
                />
              </motion.div>

              {/* Win/Loss Stats */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.15 }}
                className="grid md:grid-cols-2 gap-6 mb-6"
              >
                <GlowCard>
                  <h2 className="text-lg font-bold mb-4">Vitorias e Derrotas</h2>
                  <div className="grid grid-cols-4 gap-4 text-center">
                    <div>
                      <p className="text-2xl font-bold text-green-500">{player.wins}</p>
                      <p className="text-xs text-muted-foreground">Vitorias</p>
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-green-400">{player.wins_ot}</p>
                      <p className="text-xs text-muted-foreground">V. OT</p>
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-orange-400">{player.losses_ot}</p>
                      <p className="text-xs text-muted-foreground">D. OT</p>
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-red-500">{player.losses}</p>
                      <p className="text-xs text-muted-foreground">Derrotas</p>
                    </div>
                  </div>
                  <div className="mt-4 pt-4 border-t border-border">
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Win Rate</span>
                      <span className={cn(
                        "font-bold",
                        parseFloat(getWinRate()) >= 50 ? "text-green-500" : "text-red-500"
                      )}>
                        {getWinRate()}%
                      </span>
                    </div>
                    <div className="w-full h-2 bg-secondary rounded-full mt-2 overflow-hidden">
                      <div 
                        className={cn(
                          "h-full rounded-full",
                          parseFloat(getWinRate()) >= 50 ? "bg-green-500" : "bg-red-500"
                        )}
                        style={{ width: `${getWinRate()}%` }}
                      />
                    </div>
                  </div>
                </GlowCard>

                <GlowCard>
                  <h2 className="text-lg font-bold mb-4">Medias por Partida</h2>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Kills</span>
                      <span className="font-bold text-green-500">{getAvgKills()}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Mortes</span>
                      <span className="font-bold text-red-500">{getAvgDeaths()}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Assists</span>
                      <span className="font-bold text-blue-500">{getAvgAssists()}</span>
                    </div>
                    <div className="flex items-center justify-between pt-4 border-t border-border">
                      <span className="text-muted-foreground">KOST</span>
                      <span className="font-bold text-foreground">{player.kost}%</span>
                    </div>
                  </div>
                </GlowCard>
              </motion.div>

              {/* Streak */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="mb-6"
              >
                <GlowCard>
                  <div className="flex items-center justify-between">
                    <div>
                      <h2 className="text-lg font-bold mb-1">Sequencia Atual</h2>
                      <p className="text-sm text-muted-foreground">
                        {player.current_streak > 0 
                          ? `${player.current_streak} vitorias consecutivas` 
                          : player.current_streak < 0 
                          ? `${Math.abs(player.current_streak)} derrotas consecutivas`
                          : 'Sem sequencia'}
                      </p>
                    </div>
                    <div className={cn(
                      "text-4xl font-black flex items-center gap-2",
                      player.current_streak > 0 ? "text-green-500" : player.current_streak < 0 ? "text-red-500" : "text-muted-foreground"
                    )}>
                      {player.current_streak > 0 ? (
                        <>
                          <TrendingUp className="w-8 h-8" />
                          +{player.current_streak}
                        </>
                      ) : player.current_streak < 0 ? (
                        <>
                          <TrendingDown className="w-8 h-8" />
                          {player.current_streak}
                        </>
                      ) : (
                        <>
                          <Minus className="w-8 h-8" />
                          0
                        </>
                      )}
                    </div>
                  </div>
                </GlowCard>
              </motion.div>

              {/* Recent Matches */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.25 }}
              >
                <h2 className="text-xl font-bold mb-4">Partidas Recentes</h2>
                {recentMatches.length === 0 ? (
                  <GlowCard className="text-center py-8">
                    <p className="text-muted-foreground">Nenhuma partida registrada</p>
                  </GlowCard>
                ) : (
                  <div className="space-y-3">
                    {recentMatches.map((match, index) => {
                      const isWinner = (match.winner === 'TEAM_A' && match.match_player.team === 'TEAM_A') ||
                                       (match.winner === 'TEAM_B' && match.match_player.team === 'TEAM_B')
                      return (
                        <motion.div
                          key={match.id}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: 0.3 + index * 0.05 }}
                        >
                          <Link href={`/partidas/${match.id}`}>
                            <GlowCard className="cursor-pointer">
                              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
                                {/* Result indicator */}
                                <div className={cn(
                                  "w-2 h-full min-h-[60px] rounded-full hidden sm:block",
                                  isWinner ? "bg-green-500" : "bg-red-500"
                                )} />

                                {/* Match info */}
                                <div className="flex-1">
                                  <div className="flex items-center gap-3 mb-2">
                                    <span className={cn(
                                      "px-2 py-1 rounded-full text-xs font-bold",
                                      isWinner ? "bg-green-500/20 text-green-500" : "bg-red-500/20 text-red-500"
                                    )}>
                                      {isWinner ? 'VITORIA' : 'DERROTA'}
                                    </span>
                                    <span className="text-sm text-muted-foreground">
                                      {match.map?.name}
                                    </span>
                                    <span className="text-xs text-muted-foreground">
                                      {new Date(match.match_date).toLocaleDateString('pt-BR')}
                                    </span>
                                  </div>
                                  <div className="flex items-center gap-4 text-sm">
                                    <span className="font-bold">
                                      {match.team_a_score} x {match.team_b_score}
                                    </span>
                                    <span className="text-muted-foreground">•</span>
                                    <span className="text-green-500">{match.match_player.kills}K</span>
                                    <span className="text-red-500">{match.match_player.deaths}D</span>
                                    <span className="text-blue-500">{match.match_player.assists}A</span>
                                  </div>
                                </div>

                                {/* MVP badge */}
                                {match.match_player.is_mvp && (
                                  <div className="flex items-center gap-1 text-primary">
                                    <Trophy className="w-4 h-4" />
                                    <span className="text-sm font-medium">MVP</span>
                                  </div>
                                )}

                                <ChevronRight className="w-5 h-5 text-muted-foreground" />
                              </div>
                            </GlowCard>
                          </Link>
                        </motion.div>
                      )
                    })}
                  </div>
                )}
              </motion.div>
            </>
          )}
        </div>
      </main>
    </div>
  )
}
