'use client'

import { useEffect, useState, useCallback } from 'react'
import { createClient } from '@/lib/supabase/client'
import type { Player, Match, Lobby, LobbyPlayer, Map, Season, Announcement, Setting, DrawResult, MatchPlayer } from '@/lib/types/database'

const supabase = createClient()

// Players
export function usePlayers() {
  const [players, setPlayers] = useState<Player[]>([])
  const [loading, setLoading] = useState(true)

  const fetchPlayers = useCallback(async () => {
    const { data, error } = await supabase
      .from('players')
      .select('*')
      .order('points', { ascending: false })
    
    if (!error && data) {
      setPlayers(data)
    }
    setLoading(false)
  }, [])

  useEffect(() => {
    fetchPlayers()

    const channel = supabase
      .channel('players-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'players' }, () => {
        fetchPlayers()
      })
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [fetchPlayers])

  return { players, loading, refetch: fetchPlayers }
}

// Single Player
export function usePlayer(nickname: string) {
  const [player, setPlayer] = useState<Player | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchPlayer() {
      const { data, error } = await supabase
        .from('players')
        .select('*')
        .eq('nickname', nickname)
        .single()
      
      if (!error && data) {
        setPlayer(data)
      }
      setLoading(false)
    }

    if (nickname) {
      fetchPlayer()
    }
  }, [nickname])

  return { player, loading }
}

// Matches
export function useMatches() {
  const [matches, setMatches] = useState<Match[]>([])
  const [loading, setLoading] = useState(true)

  const fetchMatches = useCallback(async () => {
    const { data, error } = await supabase
      .from('matches')
      .select(`
        *,
        map:maps(*),
        mvp_player:players!matches_mvp_player_id_fkey(*),
        match_players(
          *,
          player:players(*)
        )
      `)
      .order('match_date', { ascending: false })
    
    if (!error && data) {
      setMatches(data)
    }
    setLoading(false)
  }, [])

  useEffect(() => {
    fetchMatches()

    const channel = supabase
      .channel('matches-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'matches' }, () => {
        fetchMatches()
      })
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [fetchMatches])

  return { matches, loading, refetch: fetchMatches }
}

// Lobby
export function useLobby() {
  const [lobby, setLobby] = useState<Lobby | null>(null)
  const [players, setPlayers] = useState<LobbyPlayer[]>([])
  const [loading, setLoading] = useState(true)

  const fetchLobby = useCallback(async () => {
    const { data: lobbyData } = await supabase
      .from('lobby')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(1)
      .single()

    if (lobbyData) {
      setLobby(lobbyData)

      const { data: playersData } = await supabase
        .from('lobby_players')
        .select('*')
        .eq('lobby_id', lobbyData.id)
        .order('joined_at', { ascending: true })

      if (playersData) {
        setPlayers(playersData)
      }
    }
    setLoading(false)
  }, [])

  useEffect(() => {
    fetchLobby()

    const lobbyChannel = supabase
      .channel('lobby-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'lobby' }, () => {
        fetchLobby()
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'lobby_players' }, () => {
        fetchLobby()
      })
      .subscribe()

    return () => {
      supabase.removeChannel(lobbyChannel)
    }
  }, [fetchLobby])

  return { lobby, players, loading, refetch: fetchLobby }
}

// Maps
export function useMaps() {
  const [maps, setMaps] = useState<Map[]>([])
  const [loading, setLoading] = useState(true)

  const fetchMaps = useCallback(async () => {
    const { data, error } = await supabase
      .from('maps')
      .select('*')
      .order('name')
    
    if (!error && data) {
      setMaps(data)
    }
    setLoading(false)
  }, [])

  useEffect(() => {
    fetchMaps()
  }, [fetchMaps])

  return { maps, loading, refetch: fetchMaps }
}

// Seasons
export function useSeasons() {
  const [seasons, setSeasons] = useState<Season[]>([])
  const [activeSeason, setActiveSeason] = useState<Season | null>(null)
  const [loading, setLoading] = useState(true)

  const fetchSeasons = useCallback(async () => {
    const { data, error } = await supabase
      .from('seasons')
      .select('*')
      .order('created_at', { ascending: false })
    
    if (!error && data) {
      setSeasons(data)
      const active = data.find(s => s.is_active)
      setActiveSeason(active || null)
    }
    setLoading(false)
  }, [])

  useEffect(() => {
    fetchSeasons()
  }, [fetchSeasons])

  return { seasons, activeSeason, loading, refetch: fetchSeasons }
}

// Settings
export function useSettings() {
  const [settings, setSettings] = useState<Record<string, string>>({})
  const [loading, setLoading] = useState(true)

  const fetchSettings = useCallback(async () => {
    const { data, error } = await supabase
      .from('settings')
      .select('*')
    
    if (!error && data) {
      const settingsObj: Record<string, string> = {}
      data.forEach((s: Setting) => {
        if (s.value) settingsObj[s.key] = s.value
      })
      setSettings(settingsObj)
    }
    setLoading(false)
  }, [])

  useEffect(() => {
    fetchSettings()

    const channel = supabase
      .channel('settings-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'settings' }, () => {
        fetchSettings()
      })
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [fetchSettings])

  return { settings, loading, refetch: fetchSettings }
}

// Announcements
export function useAnnouncements(type?: 'lobby' | 'matchmaking' | 'general') {
  const [announcements, setAnnouncements] = useState<Announcement[]>([])
  const [loading, setLoading] = useState(true)

  const fetchAnnouncements = useCallback(async () => {
    let query = supabase
      .from('announcements')
      .select('*')
      .eq('is_active', true)
      .order('created_at', { ascending: false })
    
    if (type) {
      query = query.eq('type', type)
    }
    
    const { data, error } = await query
    
    if (!error && data) {
      setAnnouncements(data)
    }
    setLoading(false)
  }, [type])

  useEffect(() => {
    fetchAnnouncements()

    const channel = supabase
      .channel('announcements-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'announcements' }, () => {
        fetchAnnouncements()
      })
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [fetchAnnouncements])

  return { announcements, loading, refetch: fetchAnnouncements }
}

// Draw Results
export function useDrawResults() {
  const [drawResults, setDrawResults] = useState<DrawResult[]>([])
  const [loading, setLoading] = useState(true)

  const fetchDrawResults = useCallback(async () => {
    const { data, error } = await supabase
      .from('draw_results')
      .select(`
        *,
        map:maps(*)
      `)
      .order('created_at', { ascending: false })
    
    if (!error && data) {
      setDrawResults(data)
    }
    setLoading(false)
  }, [])

  useEffect(() => {
    fetchDrawResults()

    const channel = supabase
      .channel('draw-results-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'draw_results' }, () => {
        fetchDrawResults()
      })
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [fetchDrawResults])

  return { drawResults, loading, refetch: fetchDrawResults }
}

// Global Stats
export function useGlobalStats() {
  const [stats, setStats] = useState({
    totalPlayers: 0,
    totalMatches: 0,
    totalKills: 0,
    mvpPlayer: null as Player | null
  })
  const [loading, setLoading] = useState(true)

  const fetchStats = useCallback(async () => {
    const [playersRes, matchesRes] = await Promise.all([
      supabase.from('players').select('*'),
      supabase.from('matches').select('*').eq('status', 'finished')
    ])

    if (playersRes.data) {
      const totalKills = playersRes.data.reduce((sum, p) => sum + (p.kills || 0), 0)
      const mvp = playersRes.data.reduce((prev, current) => 
        (prev.mvp_count > current.mvp_count) ? prev : current
      , playersRes.data[0])

      setStats({
        totalPlayers: playersRes.data.length,
        totalMatches: matchesRes.data?.length || 0,
        totalKills,
        mvpPlayer: mvp
      })
    }
    setLoading(false)
  }, [])

  useEffect(() => {
    fetchStats()

    const channel = supabase
      .channel('global-stats')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'players' }, () => {
        fetchStats()
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'matches' }, () => {
        fetchStats()
      })
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [fetchStats])

  return { stats, loading, refetch: fetchStats }
}
