"use client"

import { useState, useEffect } from 'react'
import { createClient } from '@/lib/supabase/client'
import { 
  RankThresholds, 
  DEFAULT_RANK_THRESHOLDS, 
  parseThresholdsFromSettings,
  buildRanksFromThresholds,
  type RankInfo
} from '@/lib/utils/ranks'

let cachedThresholds: RankThresholds | null = null
let cachedRanks: RankInfo[] | null = null

export function useRankThresholds() {
  const [thresholds, setThresholds] = useState<RankThresholds>(cachedThresholds || DEFAULT_RANK_THRESHOLDS)
  const [ranks, setRanks] = useState<RankInfo[]>(cachedRanks || buildRanksFromThresholds(DEFAULT_RANK_THRESHOLDS))
  const [loading, setLoading] = useState(!cachedThresholds)
  
  const supabase = createClient()

  useEffect(() => {
    if (cachedThresholds) return
    
    async function fetchThresholds() {
      const { data } = await supabase
        .from('settings')
        .select('value')
        .eq('key', 'rank_thresholds')
        .single()
      
      if (data?.value) {
        const parsed = parseThresholdsFromSettings(data.value)
        cachedThresholds = parsed
        cachedRanks = buildRanksFromThresholds(parsed)
        setThresholds(parsed)
        setRanks(cachedRanks)
      }
      setLoading(false)
    }

    fetchThresholds()

    // Subscribe to changes in settings
    const channel = supabase
      .channel('rank_thresholds_changes')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'settings',
        filter: 'key=eq.rank_thresholds'
      }, (payload) => {
        if (payload.new && 'value' in payload.new) {
          const parsed = parseThresholdsFromSettings(payload.new.value as string)
          cachedThresholds = parsed
          cachedRanks = buildRanksFromThresholds(parsed)
          setThresholds(parsed)
          setRanks(cachedRanks)
        }
      })
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [supabase])

  return { thresholds, ranks, loading }
}

// Function to invalidate cache (call after saving new thresholds)
export function invalidateRankThresholdsCache() {
  cachedThresholds = null
  cachedRanks = null
}
