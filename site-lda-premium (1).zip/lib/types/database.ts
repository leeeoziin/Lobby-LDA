export interface Player {
  id: string
  nickname: string
  avatar_url: string | null
  banner_url: string | null
  platform: 'PC' | 'Xbox' | 'PSN'
  elo: number
  kills: number
  deaths: number
  assists: number
  matches_played: number
  wins: number
  wins_ot: number
  losses_ot: number
  losses: number
  points: number
  mvp_count: number
  current_streak: number
  kost: number
  created_at: string
  updated_at: string
}

export interface Season {
  id: string
  name: string
  start_date: string | null
  end_date: string | null
  is_active: boolean
  created_at: string
}

export interface Map {
  id: string
  name: string
  image_url: string | null
  is_active: boolean
  created_at: string
}

export interface Match {
  id: string
  season_id: string | null
  map_id: string | null
  team_a_score: number
  team_b_score: number
  team_a_side: 'ATAQUE' | 'DEFESA' | null
  team_b_side: 'ATAQUE' | 'DEFESA' | null
  mvp_player_id: string | null
  winner: 'TEAM_A' | 'TEAM_B' | null
  is_overtime: boolean
  status: 'pending' | 'in_progress' | 'finished'
  image_url: string | null
  screenshot_url: string | null
  match_date: string
  created_at: string
  updated_at: string
  map?: Map
  mvp_player?: Player
  match_players?: MatchPlayer[]
}

export interface MatchPlayer {
  id: string
  match_id: string
  player_id: string
  team: 'TEAM_A' | 'TEAM_B'
  kills: number
  deaths: number
  assists: number
  entry_kills: number
  clutches: number
  is_mvp: boolean
  player?: Player
}

export interface Lobby {
  id: string
  is_open: boolean
  max_players: number
  max_reserves: number
  scheduled_datetime: string | null
  created_at: string
  updated_at: string
}

export interface LobbyPlayer {
  id: string
  lobby_id: string
  player_id: string | null
  nickname: string
  platform: 'PC' | 'Xbox' | 'PSN'
  is_reserve: boolean
  joined_at: string
  player?: Player
}

export interface DrawResult {
  id: string
  lobby_id: string | null
  match_id: string | null
  map_id: string | null
  team_a_players: { nickname: string; platform: string }[]
  team_b_players: { nickname: string; platform: string }[]
  team_a_side: 'ATAQUE' | 'DEFESA'
  team_b_side: 'ATAQUE' | 'DEFESA'
  created_at: string
  map?: Map
}

export interface Setting {
  id: string
  key: string
  value: string | null
  updated_at: string
}

export interface Announcement {
  id: string
  title: string | null
  message: string
  type: 'lobby' | 'matchmaking' | 'general'
  is_active: boolean
  created_at: string
}

export interface PlayerSeasonStats {
  id: string
  player_id: string
  season_id: string
  kills: number
  deaths: number
  assists: number
  matches_played: number
  wins: number
  wins_ot: number
  losses_ot: number
  losses: number
  points: number
  elo: number
  mvp_count: number
}
