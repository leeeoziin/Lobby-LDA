// Ranking System for LDA Lobby Premium
// Ranks from lowest to highest: Copper, Bronze, Prata, Ouro, Diamante, Champions

export type RankTier = 'copper' | 'bronze' | 'prata' | 'ouro' | 'diamante' | 'champions'

export interface RankInfo {
  tier: RankTier
  name: string
  minElo: number
  maxElo: number
  color: string
  bgColor: string
  borderColor: string
  icon: string
}

export const RANKS: RankInfo[] = [
  {
    tier: 'copper',
    name: 'Copper',
    minElo: 0,
    maxElo: 799,
    color: 'text-orange-700',
    bgColor: 'bg-orange-700/20',
    borderColor: 'border-orange-700',
    icon: '🥉'
  },
  {
    tier: 'bronze',
    name: 'Bronze',
    minElo: 800,
    maxElo: 1099,
    color: 'text-amber-600',
    bgColor: 'bg-amber-600/20',
    borderColor: 'border-amber-600',
    icon: '🥉'
  },
  {
    tier: 'prata',
    name: 'Prata',
    minElo: 1100,
    maxElo: 1399,
    color: 'text-slate-400',
    bgColor: 'bg-slate-400/20',
    borderColor: 'border-slate-400',
    icon: '🥈'
  },
  {
    tier: 'ouro',
    name: 'Ouro',
    minElo: 1400,
    maxElo: 1699,
    color: 'text-yellow-500',
    bgColor: 'bg-yellow-500/20',
    borderColor: 'border-yellow-500',
    icon: '🥇'
  },
  {
    tier: 'diamante',
    name: 'Diamante',
    minElo: 1700,
    maxElo: 1999,
    color: 'text-cyan-400',
    bgColor: 'bg-cyan-400/20',
    borderColor: 'border-cyan-400',
    icon: '💎'
  },
  {
    tier: 'champions',
    name: 'Champions',
    minElo: 2000,
    maxElo: Infinity,
    color: 'text-purple-500',
    bgColor: 'bg-purple-500/20',
    borderColor: 'border-purple-500',
    icon: '👑'
  }
]

export function getRankByElo(elo: number): RankInfo {
  for (const rank of RANKS) {
    if (elo >= rank.minElo && elo <= rank.maxElo) {
      return rank
    }
  }
  return RANKS[0] // Default to copper
}

export function getRankTierValue(tier: RankTier): number {
  const index = RANKS.findIndex(r => r.tier === tier)
  return index >= 0 ? index : 0
}

// Balance teams by trying to equalize total ELO
export function balanceTeams(players: { nickname: string; platform: string; elo: number }[]): {
  teamA: typeof players
  teamB: typeof players
} {
  if (players.length !== 10) {
    throw new Error('Need exactly 10 players to balance teams')
  }

  // Sort players by ELO descending
  const sorted = [...players].sort((a, b) => b.elo - a.elo)
  
  const teamA: typeof players = []
  const teamB: typeof players = []
  let teamAElo = 0
  let teamBElo = 0

  // Snake draft: assign players alternating to balance ELO
  for (let i = 0; i < sorted.length; i++) {
    const player = sorted[i]
    
    // Assign to team with lower total ELO
    if (teamA.length < 5 && (teamAElo <= teamBElo || teamB.length >= 5)) {
      teamA.push(player)
      teamAElo += player.elo
    } else if (teamB.length < 5) {
      teamB.push(player)
      teamBElo += player.elo
    } else {
      teamA.push(player)
      teamAElo += player.elo
    }
  }

  return { teamA, teamB }
}

// Calculate average team ELO
export function getTeamAverageElo(players: { elo: number }[]): number {
  if (players.length === 0) return 0
  const total = players.reduce((sum, p) => sum + p.elo, 0)
  return Math.round(total / players.length)
}
